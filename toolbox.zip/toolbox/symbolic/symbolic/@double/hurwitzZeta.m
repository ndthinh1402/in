function Z = hurwitzZeta(varargin)
%HURWITZZETA   Symbolic Hurwitz zeta function.
%   Z = hurwitzZeta(S,A) returns the Hurwitz zeta function.
%
%   Z = hurwitzZeta(N,S,A) Nth derivative of hurwitzZeta(S,A).
%
%   See also: sym/hurwitzZeta, zeta

%   Copyright 2018 The MathWorks, Inc.

narginchk(2, 3);
Z = sym.useSymForNumeric(@hurwitzZeta, varargin{:});
end