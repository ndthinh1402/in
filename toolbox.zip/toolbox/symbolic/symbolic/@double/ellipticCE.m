function Y=ellipticCE(M)
%ellipticCE  Complementary complete elliptic integral of the second kind
%   Y = ellipticCE(M) returns the complementary complete elliptic integral
%   of the first kind, evaluated for each element of M.
%
%   See also SYM/ELLIPKE, SYM/ellipticE, SYM/ellipticK, SYM/ellipticCK,
%   SYM/ellipticF, SYM/ellipticPi, SYM/ellipticCPi, SYM/ellipticNome.

% Copyright 2012-2016 The MathWorks, Inc.
Y = sym.useSymForNumeric(@ellipticCE, M);
