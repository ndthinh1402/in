function Z = zeta(varargin)
%ZETA   Symbolic Riemann zeta function.
%   Z = zeta(S) returns the Riemann zeta function.
%
%   Z = zeta(N,S) returns the Nth derivative of zeta(S).
%
%   See also: hurwitzZeta

%   Copyright 2009-2018 The MathWorks, Inc.

narginchk(1,2);
Z = sym.useSymForNumeric(@zeta, varargin{:});
