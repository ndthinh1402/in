function Q=ellipticNome(M)
%ellipticNome   Elliptic nome function
%   Q = ellipticNome(M) returns the elliptic nome function, evaluated 
%   for each element of M.
%
%   See also SYM/ELLIPKE, SYM/ellipticE, SYM/ellipticK, SYM/ellipticCK, 
%   SYM/ellipticCE, SYM/ellipticF, SYM/ellipticPi, SYM/ellipticCPi.

%   Copyright 2016 The MathWorks, Inc.

Q = sym.useSymForNumeric(@ellipticNome, M);
