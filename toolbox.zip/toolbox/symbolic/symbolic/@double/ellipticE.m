function Y=ellipticE(varargin)
%ellipticE  Elliptic integral of the second kind
%   Y = ellipticE(M) returns the complete elliptic integral of the second kind,
%   evaluated for each element of M.
%
%   Y = ellipticE(PHI, M) returns the incomplete elliptic integral of the second kind,
%   evaluated for each pair of elements of PHI and M.
%
%   See also SYM/ELLIPKE, SYM/ellipticK, SYM/ellipticCK, SYM/ellipticCE,
%   SYM/ellipticF, SYM/ellipticPi, SYM/ellipticCPi, SYM/ellipticNome.

% Copyright 2012-2016 The MathWorks, Inc.
narginchk(1,3);
Y = sym.useSymForNumeric(@ellipticE, varargin{:});
