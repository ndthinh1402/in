function Y=ellipticCPi(N, M)
%ellipticCPi  Complementary complete elliptic integral of the third kind
%   Y = ellipticCPi(N, M) returns the complementary complete elliptic integral
%   of the third kind, evaluated for each pair of elements of N and M.
%
%   See also SYM/ELLIPKE, SYM/ellipticE, SYM/ellipticK, SYM/ellipticCE, 
%   SYM/ellipticCK, SYM/ellipticF, SYM/ellipticPi, SYM/ellipticNome.

% Copyright 2012-2016 The MathWorks, Inc.
Y = sym.useSymForNumeric(@ellipticCPi, N, M);
