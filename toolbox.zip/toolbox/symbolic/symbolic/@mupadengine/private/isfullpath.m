% test for full path name
function isfull = isfullpath(p)
    if nargin > 0
        p = convertStringsToChars(p);
    end
    
    if ispc
        p(p=='/') = '\';
        isfull = strncmp(p,'\\',2) || (length(p)>2 && strcmp(p(2:3),':\'));
    else
        isfull = p(1) == filesep;
    end
end