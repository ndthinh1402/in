function B = isprime(N)
%ISPRIME True for prime numbers.
%   ISPRIME(N) returns logical 1 for the elements of N that are prime, 
%   and logical 0 otherwise.
%
%   Examples:
%      isprime(sym(5)) returns true.
%      isprime(sym([1 2 6 13])) returns [false true false true].
%
%   See also SYM/DIVISORS, SYM/FACTOR, SYM/NEXTPRIME, SYM/PREVPRIME.

%   Copyright 2016-2017 The MathWorks, Inc.

N = feval_internal(symengine, 'symobj::map', N, 'specfunc::makeInteger');
T = feval_internal(symengine, 'symobj::map', N, 'testtype', 'DOM_INT');
if ~all(T)
    error(message('symbolic:sym:InputMustBeRealInteger'))
end
B = logical(feval_internal(symengine, 'symobj::map', N, 'symobj::isprime'));
end
