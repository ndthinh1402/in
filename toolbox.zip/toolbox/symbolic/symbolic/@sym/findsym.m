function v = findsym(~,~) %#ok
%FINDSYM Finds the symbolic variables in a symbolic expression or matrix.
%
%   ================================================================
%   FINDSYM has been removed. Use SYMVAR instead.
%   ================================================================
%

%   Copyright 1993-2018 The MathWorks, Inc.

error(message('symbolic:sym:DeprecateFindsym'));