function Y = asecd(X)
% asecd Inverse secant, result in degrees.
%   asecd(X) is the inverse secant expressed in degrees,
%   of the elements of X, for symbolic X.
% 
%   See also asecd, sym/acscd, sym/asin, sym/sec, sym/secd.

%   Copyright 2017-2019 The MathWorks, Inc.

Y = asec(X) * sym('180')/sym(pi);
end
