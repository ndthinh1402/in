function Y=jacobiSD(U,M)
%jacobiSD   Symbolic Jacobi elliptic function SD.
%   Y = jacobiSD(U,M) returns the Jacobi elliptic function SD,
%   evaluated for each element of U and M.
%
%   See also jacobiAM, jacobiCD, jacobiCN, jacobiCS, jacobiDC, 
%   jacobiDN, jacobiDS, jacobiNC, jacobiND, jacobiNS, jacobiSC, 
%   jacobiSN, jacobiZeta, ELLIPJ, ELLIPKE, ellipticCE, ellipticCK,
%   ellipticCPi, ellipticE, ellipticF, ellipticK, ellipticNome,
%   ellipticPi.

%   Copyright 2016 The MathWorks, Inc.

Y = privBinaryOp(U, M, 'symobj::vectorizeSpecfunc', 'jacobiSD', 'infinity');
end
