function Y=jacobiCS(U,M)
%jacobiCS   Symbolic Jacobi elliptic function CS. 
%   Y = jacobiCS(U,M) returns the Jacobi elliptic function CS,
%   evaluated for each element of U and M.
%
%   See also jacobiAM, jacobiCD, jacobiCN, jacobiDC, jacobiDN, 
%   jacobiDS, jacobiNC, jacobiND, jacobiNS, jacobiSC, jacobiSD, 
%   jacobiSN, jacobiZeta, ELLIPJ, ELLIPKE, ellipticCE, ellipticCK,
%   ellipticCPi, ellipticE, ellipticF, ellipticK, ellipticNome,
%   ellipticPi.

%   Copyright 2016 The MathWorks, Inc.

Y = privBinaryOp(U, M, 'symobj::vectorizeSpecfunc', 'jacobiCS', 'infinity');
end
