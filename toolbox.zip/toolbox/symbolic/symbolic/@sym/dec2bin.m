function S = dec2bin(D,varargin)
%DEC2BIN Convert symbolic decimal integer to its binary representation
%   dec2bin(D) returns a character array where each row is the
%   binary representation of each decimal integer in D.
%   D must contain non-negative integers.
%
%   dec2bin(D,N) produces a character array where each row
%   represents a binary number with at least N digits.
%
%   Example:
%      dec2bin(sym(23)) returns '10111'
%
%   See also SYM/DEC2HEX, STR2SYM, SYM.

%   Copyright 2019 The MathWorks, Inc.

narginchk(1,2);
try
    S = dec2number(2,D,varargin{:});
catch ME
    error(ME.identifier,ME.message);
end
