function Y = acscd(X)
% acscd Inverse cosecant, result in degrees.
%   acscd(X) is the inverse cosecant expressed in degrees,
%   of the elements of X, for symbolic X.
%
%   See also acscd, sym/acos, sym/asecd, sym/csc, sym/cscd.

%   Copyright 2017-2019 The MathWorks, Inc.

Y = acsc(X) * sym('180')/sym(pi);
end
