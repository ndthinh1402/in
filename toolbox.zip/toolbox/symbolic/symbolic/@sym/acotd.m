function Y = acotd(X)
% sind Inverse cotangent, result in degrees.
%   acotd(X) is the inverse cotangent expressed in degrees,
%   of the elements of X, for symbolic X.
%
%   See also acotd, sym/acosd, sym/cot, sym/cotd, sym/asind, sym/atand.

%   Copyright 2017-2019 The MathWorks, Inc.

Y = acot(X) * sym('180')/sym(pi);
end
