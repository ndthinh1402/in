function B = isCondition(x)
%  isCondition(x)
%
%  Static hidden sym method to check if the argument is a symbolic condition

%   Copyright 2017-2018 The MathWorks, Inc.
  B = ~(sym.isVariable(formula(x))) & logical(feval_internal(symengine,'symobj::map',x,'testtype','Type::Condition'));
end
