function Y=ellipticCK(M)
%ellipticCK  Complementary complete elliptic integral of the first kind
%   Y = ellipticCK(M) returns the complementary complete elliptic integral
%   of the first kind, evaluated for each element of M.
%
%   See also SYM/ELLIPKE, SYM/ellipticE, SYM/ellipticK, SYM/ellipticCE,
%   SYM/ellipticF, SYM/ellipticPi, SYM/ellipticCPi, SYM/ellipticNome.

%   Copyright 2013-2016 The MathWorks, Inc.

Y = privUnaryOp(M, 'symobj::vectorizeSpecfunc', 'ellipticCK', 'infinity');
end
