function Y=jacobiNS(U,M)
%jacobiNS   Symbolic Jacobi elliptic function NS.
%   Y = jacobiNS(U,M) returns the Jacobi elliptic function NS,
%   evaluated for each element of U and M.
%
%   See also jacobiAM, jacobiCD, jacobiCN, jacobiCS, jacobiDC, 
%   jacobiDN, jacobiDS, jacobiNC, jacobiND, jacobiSC, jacobiSD, 
%   jacobiSN, jacobiZeta, ELLIPJ, ELLIPKE, ellipticCE, ellipticCK,
%   ellipticCPi, ellipticE, ellipticF, ellipticK, ellipticNome,
%   ellipticPi.

%   Copyright 2016 The MathWorks, Inc.

Y = privBinaryOp(U, M, 'symobj::vectorizeSpecfunc', 'jacobiNS', 'infinity');
end
