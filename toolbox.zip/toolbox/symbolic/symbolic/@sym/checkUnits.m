function S = checkUnits(A, varargin)
%CHECKUNITS     Check for compatibility and consistency of units
%   S = CHECKUNITS(A) checks if the units in the symbolic expression,
%   vector, or array A are compatible and consistent. The return
%   value S is a struct with two fields 'Compatible' and 'Consistent'.
%   The values of S.Compatible and S.Consistent are logicals of the
%   same shape and size as A, with entries 'true' and 'false'
%   indicating whether the corresponding entries in A are compatible
%   or consistent, respectively.
%   
%   b = CHECKUNITS(A, 'Compatible') returns a logical of the same
%   shape and size as A, indicating whether the units in the entries 
%   of A are compatible.
%   
%   b = CHECKUNITS(A, 'Consistent') returns a logical of the same
%   shape and size as A, indicating whether the units in the entries 
%   of A are compatible.
%
%   Symbolic variables in A are regarded as dimensionless quantities.
%
%   Examples:
%     >> u = symunit;
%     >> S = checkUnits(u.m + 100*u.cm);
%     >> S.Compatible
%
%     ans =
%
%       1
%
%     >> S.Consistent
%
%     ans =
%
%       0
%
%     >> A = magic(2)*u.m;
%     >> A(2,1) = A(2,1) + u.kg;
%     >> S = checkUnits(A);
%     >> S.Compatible
%
%     ans =
%
%       1   1
%       0   1
%
%     >> S.Consistent
%
%     ans =
%
%       1   1
%       0   1
%
%   See also ISUNIT, REWRITE, SYMUNIT, UNITCONVERSIONFACTOR.

%   Copyright 2016-2017 The MathWorks, Inc.

narginchk(1, 2);

p = inputParser;
p.addRequired('A', @(x) isa(x, 'sym'));
p.addOptional('opt', '', @(x) true);
p.parse(A, varargin{:});
A = p.Results.A;
opt = p.Results.opt;

if nargin > 1
  try
    validateattributes(opt, {'char', 'string'},{'scalartext'});
    opt = char(opt);
    opt = validatestring(opt, {'Consistent','Compatible'});
  catch err
    error(message('symbolic:unit:InvalidOptionConsistentOrCompatible'));
  end
end

args = privResolveArgs(A);
Asym = formula(args{1});

[S1,S2] = mupadmexnout('symobj::checkUnits',...
                       reshape(Asym,numel(Asym),1));

if strcmpi(opt, 'Consistent')
   S = logical(reshape(S1, size(Asym)));
elseif strcmpi(opt, 'Compatible')
   S = logical(reshape(S2, size(Asym)));
else
   S1 = logical(reshape(S1, size(Asym)));
   S2 = logical(reshape(S2, size(Asym)));
   S = struct('Consistent', S1,'Compatible', S2);
end
