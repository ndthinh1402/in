function R = deg2rad(D)
% deg2rad Convert angle from degrees to radians.
%   R = deg2rad(D) converts angle from degrees to radians for each element of D.
%
%   See also deg2rad, sym/rad2deg, sym/sind, symunit.

%   Copyright 2017-2019 The MathWorks, Inc.

narginchk(1,1);
if ~isempty(D) && ~isscalar(D)
    R = arrayfun(@deg2rad, D);
    return;
end
if has(D, [symunit('deg'), symunit('rad')])
    R = rewrite(D, symunit('rad'));
else
    R = D*sym(pi)/sym('180');
end
end
