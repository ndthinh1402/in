function Y = cotd(X)
% cotd Cotangent of argument in degrees.
%   cotd(X) is the cotangent of the elements of X, expressed in degrees,
%   for symbolic X.
%
%   See also cotd, sym/acotd, sym/cosd, sym/cot, sym/sind, sym/tand.

%   Copyright 2017-2019 The MathWorks, Inc.

planeAngle = [symunit('deg'), symunit('rad'), symunit('arcmin'), symunit('arcsec'), symunit('rev')]; 
if has(X, planeAngle)
    warning(message('symbolic:sym:sym:UnexpectedPlaneAngle', 'cot', 'cotd'));
end
Y = cot(X*sym(pi)/sym('180'));
end