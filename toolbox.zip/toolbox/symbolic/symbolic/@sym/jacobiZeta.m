function Y=jacobiZeta(U,M)
%jacobiZeta   Symbolic Jacobi zeta function.
%   Y = jacobiZeta(U,M) returns the Jacobi zeta function,
%   evaluated for each element of U and M.
%
%   See also jacobiAM, jacobiCD, jacobiCN, jacobiCS, jacobiDC, 
%   jacobiDN, jacobiDS, jacobiNC, jacobiND, jacobiNS, jacobiSC, 
%   jacobiSD, jacobiSN, ELLIPJ, ELLIPKE, ellipticCE, ellipticCK, 
%   ellipticCPi, ellipticE, ellipticF, ellipticK, ellipticNome,
%   ellipticPi, ZETA.

%   Copyright 2016 The MathWorks, Inc.

Y = privBinaryOp(U, M, 'symobj::vectorizeSpecfunc', 'jacobiZeta', 'infinity');
end
