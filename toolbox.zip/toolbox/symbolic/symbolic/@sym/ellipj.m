function [SN,CN,DN]=ellipj(U,M)
%ELLIPJ Jacobi elliptic functions.
%   [SN,CN,DN] = ELLIPJ(U,M) returns the values of the Jacobi elliptic 
%   functions SN, CN and DN, evaluated for corresponding elements of 
%   argument U and parameter M.  U and M must be arrays of the same 
%   size or either can be scalar. 
% 
%   See also jacobiAM, jacobiCD, jacobiCN, jacobiCS, jacobiDC,
%   jacobiDN, jacobiDS, jacobiNC, jacobiND, jacobiNS, jacobiSC, 
%   jacobiSD, jacobiSN, jacobiZeta, ELLIPKE, ellipticCE, ellipticCK,
%   ellipticCPi, ellipticE, ellipticF, ellipticK, ellipticNome,
%   ellipticPi.

%   Copyright 2016 The MathWorks, Inc.

SN = jacobiSN(U,M);
if nargout > 1
   CN = jacobiCN(U,M);
end
if nargout > 1
   DN = jacobiDN(U,M);
end
end

