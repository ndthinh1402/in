function Y = jacobiP(n, a, b, x)
%jacobiP   Jacobi polynomials.
%    Y = jacobiP(N, A, B, X) is the N-th Jacobi polynomial.

%   Copyright 2014-2016 The MathWorks, Inc.

Y = privQuaternaryOp(n,a,b,x, 'symobj::vectorizeSpecfunc', 'orthpoly::jacobi', 'undefined');

