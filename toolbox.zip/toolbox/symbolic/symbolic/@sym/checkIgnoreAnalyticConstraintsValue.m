function B = checkIgnoreAnalyticConstraintsValue(v)
% Static auxiliary method of the sym class:
% B = SYM.CHECKIGNOREANALYTICCONSTRAINTSVALUE(v)
% checks the value v of the option IgnoreAnalyticConstraints,
% and throws an error for invalid values.
% It returns true if v is true, and false if v is false.

%   Copyright 2014-2019 The MathWorks, Inc.

if isequal(v, true) || isequal(v, symtrue)
    B = symtrue; 
elseif isequal(v, false) || isequal(v, symfalse) 
    B = symfalse;
else
    error(message('symbolic:sym:badArgForOpt', 'IgnoreAnalyticConstraints'));
end
