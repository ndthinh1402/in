function V = eliminate(polys, vars)
%ELIMINATE Eliminate variables from a polynomial system.
%   V = ELIMINATE(POLYS, VARS)) returns a basis of the elimination ideal
%   that consists of all linear combinations of POLYS that do not contain
%   VARS. In other words, the polynomial system V does not contains VARS,
%   is implied by V, and any of its solution can be extended to a solution
%   of POLYS.
%
%   Example:
%       syms x y z
%       eliminate([x^2+y+z^2, x-2*y+z, x^2 + y*z + z^2], x)
%
%   See also GBASIS, SOLVE.

%   Copyright 2017 The MathWorks, Inc.

polys = sym(polys);
if nargin == 1
    vars = symvar(polys, 1);
end

if isempty(vars)
    % nothing to eliminate
    V = polys;
    return
end

polylist = feval_internal(symengine, 'symobj::tolist', polys);
vars = feval_internal(symengine, 'symobj::tolist', vars);
V = feval_internal(symengine, 'groebner::eliminate', polylist, vars);

if isa(polys, 'symfun')
    % return a symfun of all non-eliminated vars of the input
    args = setdiff(argnames(polys), vars, 'stable');
    if ~isempty(args)
        V = symfun(V, args);
    end
end
