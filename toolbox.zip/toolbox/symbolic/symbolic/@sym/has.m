function b = has(e, s)
%HAS Search for subexpression
%   HAS(E,S) tests whether the symbolic expression E contains the symbolic expression S.
%   It returns logical 1 (true) if E contains S, and logical 0 (false) otherwise.
%   If E is an array, HAS(E,S) returns an array of the same size as E
%   containing logical 1s (true) where the elements of E contain S,
%   and logical 0s (false) where they do not.
%   If S is an array, HAS(E,S) tests whether E contains any element of S.
%   If S is a character string representing the name of a symbolic function,
%   or a cell array of such, then HAS(E,S)
%   tests whether E contains a call to S or any element of S, respectively.
%
%   Examples:
%   has([x+1, cos(y)+1, y+z], [x, cos(y)]) returns [1 1 0].
%   has(int([tan(x), tan(x^2)], x), 'int') returns [0 1]
%   because the first integral can be computed but the second not.
%
%   See also SUBS.

%   Copyright 2015-2017 The MathWorks, Inc.

if nargin > 1
    s = convertStringsToChars(s);
end

narginchk(2, 2);
if ~isa(e, 'sym')
   error(message('symbolic:sym:sym:SymInputExpected'))
end
e = formula(e);

if iscell(s) || isa(s, 'char')
   b = arrayfun(@(X) hasFunction(X, s), e);
   return;
elseif ~isa(s, 'sym')
   error(message('symbolic:sym:sym:SymInputExpected'))
end

S = formula(s);
S = reshape(S, 1, numel(S));
% replace of NaN because == does not behave nice on it
localNaN = feval_internal(symengine, 'genident', '"NAN"');
e = subs(e, sym(NaN), localNaN);
S = subs(S, sym(NaN), localNaN);
% create new variables that we substitute into e
X = sym(zeros(1, numel(S)));
for i=1:numel(S)
    X(i) = feval_internal(symengine, 'genident', '"HAS"');
end
b = ~logical(e == subs(e, S, X));
end

function b = hasFunction(e, s)
s = sym.charToFunction(s);
s = feval_internal(symengine, 'symobj::tolist', s);
b = logical(feval_internal(symengine, 'has', e, s));
end
