function s = eval(x)
%EVAL  Evaluate a symbolic expression.
% ==========================================================
% EVAL is not recommended. Use SUBS instead.
% ==========================================================
%   EVAL(S) evaluates the character representation of the
%   symbolic expression S in the caller's workspace.
%
%   See also SUBS.

%   Copyright 1993-2019 The MathWorks, Inc.

if builtin('numel',x) ~= 1,  x = normalizesym(x);  end
s = evalin('caller',vectorize(char(x)));
