function r = horner(p,x)
%HORNER Horner polynomial representation.
%   HORNER(P) transforms the symbolic polynomial P into its Horner,
%   or nested, representation.
%
%   Example:
%       horner(x^3-6*x^2+11*x-6) returns
%           x*(x*(x-6)+11)-6
%
%       horner(x^3*y^3-6*x^2*y^2+11*x-6, x) returns
%           x*(x*(x*y^3 - 6*y^2) + 11) - 6
%
%       horner(x^3*y^3-6*x^2*y^2+11*x-6, y) returns
%           11*x + y^2*(y*x^3 - 6*x^2) - 6
%
%   See Also SIMPLIFY, FACTOR, COLLECT, SUBS.

%   Copyright 1993-2017 The MathWorks, Inc.

narginchk(1,2);

if nargin < 2
    x = arrayfun(@getSymVar, p);
    if isempty(x)
      x = sym(x);
    end
end
if ~isAllVars(x)
    error(message("symbolic:sym:SymVariableExpected"));
end
r = privBinaryOp(p, x, 'symobj::zip', 'symobj::horner');
end

function x = getSymVar(p)
    x = symvar(p,1);
    if isempty(x)
        x = sym('x'); % default
    end
end
