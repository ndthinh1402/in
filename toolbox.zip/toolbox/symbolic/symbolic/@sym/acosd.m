function Y = acosd(X)
% acosd Inverse cosine, result in degrees.
%   acosd(X) is the inverse cosine expressed in degrees,
%   of the elements of X, for symbolic X.
%
%   See also acosd, sym/acos, sym/cosd, sym/asind, sym/atand.

%   Copyright 2017-2019 The MathWorks, Inc.

Y = acos(X) * sym('180')/sym(pi);
end
