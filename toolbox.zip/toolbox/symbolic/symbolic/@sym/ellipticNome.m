function Q=ellipticNome(M)
%ellipticNome   Elliptic nome function
%   Q = ellipticNome(M) returns the elliptic nome function, evaluated 
%   for each element of M.
%
%   See also SYM/ELLIPKE, SYM/ellipticK, SYM/ellipticE, SYM/ellipticCK, 
%   SYM/ellipticCE, SYM/ellipticF, SYM/ellipticPi, SYM/ellipticCPi.

%   Copyright 2016 The MathWorks, Inc.

Q = privUnaryOp(M, 'symobj::vectorizeSpecfunc', 'ellipticNome', 'infinity');
end
