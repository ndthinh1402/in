function h = besselh(nu,k,z,scale)
%   H = BESSELH(NU,K,Z), for K = 1 or 2, computes the Hankel function
%   H1_nu(Z) or H2_nu(Z) for each element of the array Z.
%
%   H = BESSELH(NU,Z) uses K = 1.
%
%   H = BESSELH(NU,K,Z,SCALE) returns a scaled Hankel function
%   specfied by SCALE:
%       0 - (default) is the same as BESSELH(NU,K,Z)
%       1 - returns the following depending on K
%
%   H = BESSELH(NU,1,Z,1) scales H1_nu(Z) by exp(-i*Z)).
%   H = BESSELH(NU,2,Z,1) scales H2_nu(Z) by exp(+i*Z)).
%
%   The relationship between the Hankel and Bessel functions is:
%
%       besselh(nu,1,z) = besselj(nu,z) + i*bessely(nu,z)
%       besselh(nu,2,z) = besselj(nu,z) - i*bessely(nu,z)
%
%   Example:
%       >> syms z
%       >> besselh(3/2,1,z)
%
%       ans =
%           -(2^(1/2)*exp(z*1i)*(1i/z + 1))/(z^(1/2)*pi^(1/2))
%
%       >>  besselh(5,1,vpa(123))
%
%       ans =
% 
%           0.014784451552681634169087650126332 + 0.070437411086924214961061717411719i
%
%   See also AIRY, BESSELI, BESSELJ, BESSELK, BESSELY.

%   Copyright 2017 The MathWorks, Inc.

narginchk(2,4);
if nargin == 2
    z = k;
    k = 1;
    scale = 0;
elseif nargin == 3
    scale = 0;
end
if ~(isscalar(k) && (k==1 || k==2))
    error(message('symbolic:sym:besselh:InvalidSecondArgument'));
end
if ~(isscalar(scale) && (scale==0 || scale==1))
    error(message('symbolic:sym:besselh:InvalidFourthArgument'));
end
if ~(isa(nu,'sym') || isa(k,'sym') || isa(z,'sym'))
    h = besselh(nu,k,z,double(scale));
    return;
end
if scale==0
    h = privTrinaryOp(nu,k,z,'symobj::vectorizeSpecfunc','symobj::besselh','infinity');
else
    h = privTrinaryOp(nu,k,z,'symobj::vectorizeSpecfunc','symobj::scaledBesselh','infinity');
end
end
