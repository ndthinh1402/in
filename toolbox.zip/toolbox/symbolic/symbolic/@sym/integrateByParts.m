function g = integrateByParts(f, du)
%integrateByParts Integration by parts
%   integrateByparts(F, DU) applies integration by parts to all integrals
%   occurring in F. That is, any INT(H) is rewritten as INT(H/DU * DU),
%   and the factor DU is integrated.
%   
%   Examples:
%      syms u(x) v(x)
%      integrateByParts(int(diff(u)*v), diff(u)) 
%         returns u(x)*v(x) - int(u(x)*diff(v(x), x), x)
%
%      F = int(x * sin(x), 'Hold', true)
%      G = integrateByParts(F, sin(x))
%         returns - x*cos(x) - int(-cos(x), x, 'Hold', true)
%      release(G)
%         returns sin(x) - x*cos(x)
%
%      F = int(x^2 * exp(x), 'Hold', true)
%      G = integrateByParts(F, exp(x))
%         returns x^2*exp(x) - int(2*x*exp(x), x, 'Hold', true)
%      H = integrateByParts(G, exp(x))
%         returns x^2*exp(x) - 2*x*exp(x) + int(2*exp(x), x, 'Hold', true)
%      release(H)
%         returns 2*exp(x) + x^2*exp(x) - 2*x*exp(x)
%
%   See also INT, changeIntegrationVariable.

%   Copyright 2019 The MathWorks, Inc.

g = feval_internal(symengine, 'intlib::byparts', f, du, 'Evaluate');
end
