function g = changeIntegrationVariable(f, old, new)
%changeIntegrationVariable Integration by variable substitution
%   changeIntegrationVariable(F, OLD, NEW) substitutes OLD by NEW under all
%   integral signs in the expression F, performing an integration by change
%   of variables. OLD must be an expression depending on the previous 
%   integration variable, and NEW be an expression depending on the new 
%   integration variable.  
%   
%   Examples:
%      syms x t
%      F = int(cos(sin(x)))  
%      changeIntegrationVariable(F, sin(x), t) 
%         returns int(cos(t)/(1 - t^2)^(1/2), t)
%
%      F = int(x*exp(x^2), 'Hold', true) 
%      G = changeIntegrationVariable(F, x^2, t) 
%         returns int(exp(t)/2, t, 'Hold', true)
%      release(G)
%         returns exp(t)/2  
%
%   See also INT, integrateByParts.

%   Copyright 2019 The MathWorks, Inc.

x = sym(old);
if ~isscalar(x)
  error(message('symbolic:sym:changeIntegrationVariable:SecondArgumentMustBeScalar'));
end
t = sym(new);
if ~isscalar(t)
  error(message('symbolic:sym:changeIntegrationVariable:ThirdArgumentMustBeScalar'));
end
g = feval_internal(symengine, 'intlib::changevar', f, x==t, 'NoWarning', 'hold(Evaluate)');
end
