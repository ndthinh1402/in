function h = compose(f,g,varargin)
%COMPOSE Functional composition.
%   COMPOSE(f,g) returns f(g(y)) where f = f(x) and g = g(y). 
%   Here x is the symbolic variable of f as defined by SYMVAR and 
%   y is the symbolic variable of g as defined by SYMVAR.
%   If f and g are symbolic functions the x and y are the respective
%   inputs.
%
%   COMPOSE(f,g,z) returns f(g(z)) where f = f(x), g = g(y), and
%   x and y are the symbolic variables of f and g as defined by 
%   SYMVAR. 
%
%   COMPOSE(f,g,x,z) returns f(g(z)) and makes x the independent 
%   variable for f.  That is, if f = cos(x/t), then COMPOSE(f,g,x,z)
%   returns cos(g(z)/t) whereas COMPOSE(f,g,t,z) returns cos(x/g(z)).
%  
%   COMPOSE(f,g,x,y,z) returns f(g(z)) and makes x the independent
%   variable for f and y the independent variable for g.  For
%   f = cos(x/t) and g = sin(y/u), COMPOSE(f,g,x,y,z) returns
%   cos(sin(z/u)/t) whereas COMPOSE(f,g,x,u,z) returns cos(sin(y/z)/t).
% 
%   Examples:
%    syms x y z t u f2(x,y) f1(u);
%    f(x) = 1/(1 + x^2);
%    g(y) = sin(y);
%    h = x^t;
%    p = exp(-y/u);
%    compose(f,g)         returns   1/(sin(y)^2 + 1)
%    compose(f,g,z)       returns   1/(sin(z)^2 + 1)
%    compose(h,g,x,z)     returns   sin(z)^t
%    compose(h,g,t,z)     returns   x^sin(z)
%    compose(h,p,x,y,z)   returns   exp(-z/u)^t
%    compose(h,p,t,u,z)   returns   x^exp(-y/z)
%    compose(f2,f1)       returns   f2(f1(u), y)
%    compose(f2,f1,y)     returns   f2(f1(y), y)
%    compose(f2,f1,y,u)   returns   f2(x, f1(u))
%
%   See also SYM/FINVERSE, SYM/SYMVAR, SYM/SUBS, SYMFUN.

%   Copyright 1993-2017 The MathWorks, Inc.

narginchk(2,5);

% Set up the functions f and g as symbolic objects and find
% their symbolic variables varf and varg, respectively.
if ~isa(f,'sym')
    f = sym(f); 
end
isSymfun = isa(f,'symfun');

if builtin('numel',f) ~= 1,  f = normalizesym(f);  end
varf = symvar(f,1);
if ~isa(g,'sym')
    g = sym(g); 
end
if builtin('numel',g) ~= 1,  g = normalizesym(g);  end
varg = symvar(g,1);
% If either f or g is identically constant, then assign f
% the variable x and g the variable y.
if isempty(varf)
      varf = sym('x');
end
if isempty(varg)
      varg = sym('y');
end

% First consider the case where f = f(x), g = g(y) and we
% wish to compute h = f(g(y)). Or f = f(x,y), g = g(z) and 
% we wish to compute h = f(g(z),y)
if isa(f,'symfun')
    varf = symvar(argnames(f),1);
end
if isa(g,'symfun')
    varg = argnames(g);
end
varh = varg;
if isSymfun
    vars = unique(subs(argnames(f), varf, varg),'stable');
end

if nargin == 3
% This is the case where f = f(x), g = g(y), and h = f(g(z))
% for varargin{1} = "z". Or where f = f(x), g = g(x,y), and 
% h = f(g(z,y)).
    varh = sym(varargin{1});  % This is the variable "z".
    vars = varh;

elseif nargin == 4
% Here, f = f(varargin{1}, v), g = g(y) and h = f(g(z), v).
    varf = sym(varargin{1});
    varh = sym(varargin{2}); % The variable "z".
    vars = varh;

elseif nargin == 5
% In this case, f = f(varargin{1}, v), g = g(varargin{2}, w), and
% h = f(g(z,w), v).
    varf = sym(varargin{1}); % The independent variable for f
    varg = sym(varargin{2}); % The independent variable for g
    varh = sym(varargin{3}); % The variable "z".
    vars = varh;
end

if ~isAllVars(varf)
    error(message("symbolic:sym:SymVariableExpected3"));
end
if ~isAllVars(varg)
    error(message("symbolic:sym:SymVariableExpected4"));
end
if ~isAllVars(varh)
    error(message("symbolic:sym:SymVariableExpected5"));
end

h = mupadmex('symobj::compose',f.s,g.s,varf.s,varg.s,varh.s);
if isSymfun
    h = symfun(h, vars);
end
end