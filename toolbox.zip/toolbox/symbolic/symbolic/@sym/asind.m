function Y = asind(X)
% asind Inverse sine, result in degrees.
%   asind(X) is the inverse sine, expressed in degrees,
%   of the elements of X, for symbolic X.
%
%   See also asind, sym/acosd, sym/asin, sym/atand, sym/sind.

%   Copyright 2017-2019 The MathWorks, Inc.

Y = asin(X) * sym('180')/sym(pi);
end
