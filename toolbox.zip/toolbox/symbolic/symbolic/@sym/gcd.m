function [g,c,d] = gcd(A, B, x)
%GCD    Greatest common divisor.
%   G = GCD(A) is the symbolic greatest common divisor of all entries of A.
%   [G,C] = GCD(A) also returns a vector C such that A.*C = G.
%   G = GCD(A,B) is the symbolic greatest common divisor of A and B.
%   [G,C,D] = GCD(A,B,X) also returns C and D  so that G = A*C + B*D,
%   and X does not appear in the denominator of C and D. 
%   If X is missing, it is chosen using SYMVAR.
%
%   Example:
%      syms x
%      gcd(x^3-3*x^2+3*x-1,x^2-5*x+4) 
%      returns x-1
%
%   See also SYM/LCM.

%   Copyright 1993-2017 The MathWorks, Inc.

A = sym(A);

switch nargin
    case 1
        % gcd of a vector of arguments
        nargoutchk(0, 2);
        args = privResolveArgs(A);
        a = num2cell(formula(args{1}));
        if nargout < 2
            gSym = feval_internal(symengine, 'gcd', a{:});
        else
            [gSym, cSym] = gcdexmult([a{:}]);
            c = privResolveOutput(cSym, args{1});
        end    
        g = privResolveOutput(gSym, args{1});
        return
    case 2
        args = privResolveArgs(A, B); 
        if nargout >= 2
            x = symvar([symvar(args{1}), symvar(args{2})], 1);
            if isempty(x)
                % just need a dummy variable
                x = sym('x');
            end    
        end
    case 3
        args = privResolveArgs(A, B); 
        if ~sym.isVariable(x)
            error(message('symbolic:sym:gcd:invalidVariable'))
        end
end         


if nargout <= 1
    %  gcd of two arguments. A possible third argument is just ignored
    gSym = privBinaryOp(args{1}, args{2}, 'symobj::zip', 'gcd');
    g = privResolveOutput(gSym, args{1});
    return
end    
    

% extended gcd 
result = feval_internal(symengine, 'symobj::zip', args{1}, args{2}, 'symobj::gcdex', x);

if numel(formula(args{1})) == 1 && numel(formula(args{2})) == 1
    % simple case
    res = num2cell(result);
else
    res = cell(1, 3);
    for i=1:3
        res{i} = feval_internal(symengine, 'symobj::map', result, 'op', i);
    end
end
    
g = privResolveOutput(res{1}, args{1});
c = privResolveOutput(res{2}, args{1});
d = privResolveOutput(res{3}, args{1});



function [g, c] = gcdexmult(a)
% compute g = gcd(a) and a vector c with g = c.*a
x = symvar(a, 1);
if isempty(x)
    % dummy variable
    x = sym('x');
end    
g = sym(0);
c = sym([]);
for i = 1:numel(a)
    [g, v, u] = gcd(g, privsubsref(a, i), x);
    c = [v.*c u];
end



