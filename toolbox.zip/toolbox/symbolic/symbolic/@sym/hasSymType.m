function B = hasSymType(EX,T,TPARAM)
%hasSymType     Determine if a symbolic object contains subexpressions of a specified type.
%   B = hasSymType(EX,T,<TPARAM>) returns true if symbolic object EX contains a
%   subexpression of type T. Somes types T require an additional parameter TPARAM.
%
%   Examples:
%     syms f(t) s
%
%     hasSymType(f+1,"symfun")                   => 1
%     hasSymType(f+1,"symfunOf",t)               => 1
%     hasSymType(f+1,"symfunOf",s)               => 0
%     hasSymType(t+1,"variable")                 => 1
%     hasSymType([1,1/2,vpa(1.2),1i],"number")   => [1, 1, 1, 1]
%     hasSymType([1,1/2,vpa(1.2),1i],"real")     => [1, 1, 1, 0]
%     hasSymType([1,1/2,vpa(1.2),1i],"complex")  => [0, 0, 0, 1]
%     hasSymType([1,1/2,vpa(1.2),1i],"variable") => [0, 0, 0, 0]
%     hasSymType(f+1,"plus")                     => 1
%     hasSymType(f==1,"constant")                => 1
%     hasSymType(f==1,"variable")                => 1
%     hasSymType([f,1],"symfun")                 => [1,0]
%     hasSymType([f(t),1],"symfun")              => [1,0]
%     hasSymType([f,1], "symfun")                => [1,0]
%     hasSymType([f,1], "f")                     => [1,0]
%     hasSymType(diff(f), "expression")          => 1
%     hasSymType(diff(f), "diff")                => 1
%
%   See also: SYM/FINDSYMTYPE, SYM/ISSYMTYPE, SYM/MAPSYMTYPE, SYM/SYMFUNTYPE, SYM/SYMTYPE.

%   Copyright 2018 MathWorks, Inc.

narginchk(2,3);
if ischar(T)
    T = string(T);
end
if ~isStringScalar(T)
    error(message("symbolic:symtype:SecondArgMustBeTypeString"));
end
if isa(EX,"symfun")
    EX = formula(EX);
end
if ~isa(EX, "sym")
    error(message("symbolic:symtype:FirstArgMustBeSym"));
end
try
    if feval_internal(symengine, "symobj::islistyAndUnsupported", EX)
        B = strcmp(T, "unsupported");
        return;
    end
    if nargin == 2
        B = privUnaryOp(EX, 'symobj::map', 'symobj::hasSymType', """" + T + """");
    else
        if ~isa(TPARAM,'sym')
            TPARAM = sym(TPARAM);
        end
        B = privUnaryOp(EX, 'symobj::map', 'symobj::hasSymType', """" + T + """", TPARAM.s);
    end
    B = logical(B);
catch Exception
    throw(Exception);
end
end