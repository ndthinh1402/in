function Y=jacobiDS(U,M)
%jacobiDS   Symbolic Jacobi elliptic function DS.
%   Y = jacobiDS(U,M) returns the Jacobi elliptic function DS,
%   evaluated for each element of U and M.
%
%   See also jacobiAM, jacobiCD, jacobiCN, jacobiCS, jacobiDC, 
%   jacobiDN, jacobiNC, jacobiND, jacobiNS, jacobiSC, jacobiSD, 
%   jacobiSN, jacobiZeta, ELLIPJ, ELLIPKE, ellipticCE, ellipticCK,
%   ellipticCPi, ellipticE, ellipticF, ellipticK, ellipticNome,
%   ellipticPi.

%   Copyright 2016 The MathWorks, Inc.

Y = privBinaryOp(U, M, 'symobj::vectorizeSpecfunc', 'jacobiDS', 'infinity');
end
