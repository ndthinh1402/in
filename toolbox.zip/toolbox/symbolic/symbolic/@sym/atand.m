function Y = atand(X)
% atand Inverse tangent, result in degrees.
%   atand(X) is the inverse tangent expressed in degrees,
%   of the elements of X, for symbolic X.
%
%   See also atand, sym/acosd, sym/acotd, sym/asind, sym/atan, sym/atan2d.

%   Copyright 2017-2019 The MathWorks, Inc.

Y = atan(X) * sym('180')/sym(pi);
end
