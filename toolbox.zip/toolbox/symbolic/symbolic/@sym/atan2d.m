function Z = atan2d(Y,X)
% atan2d Four quadrant arctangent, result in degrees.
%   atan2d(Y,X) is the four quadrant arctangent expressed in degrees,
%   of the elements of X and Y such that -180 <= atan2d(Y,X) <= 180, 
%   for symbolic X and Y.
%
%   See also atan2d, sym/acosd, sym/acotd, sym/asind, sym/atand.

%   Copyright 2017-2019 The MathWorks, Inc.

Z = atan2(Y,X) * sym('180')/sym(pi);
end
