function B = gbasis(L, varargin)
%GBASIS Groebner basis
%   B = GBASIS(L) computes the Groebner basis of the ideal generated
%   by the elements of the vector L, viewed as polynomials in all
%   indeterminates of L.
%
%   B = GBASIS(L, VARS) computes the Groebner basis of the ideal generated
%   by the elements of the vector L, viewed as polynomials in VARS.
%
%   GBASIS(..., 'MonomialOrder', ORDER) uses the monomial order ORDER. 
%   Possible values for ORDER are: 
%   'degreeInverseLexicographic', 'degreeLexicographic', 'lexicographic'.
%   The default is 'degreeInverseLexicographic'.
%
%   Example:
%       syms x y z
%       gbasis([x^2+y, x-2*y, x+z+1])
%
%   See also SOLVE.

%   Copyright 2017 The MathWorks, Inc.

validateattributes(L, {'sym'}, {'row', 'nonempty'});
p = inputParser;
p.addOptional('vars', symvar(L), @isAllVars);
p.addParameter('MonomialOrder', 'degreeInverseLexicographic');
p.parse(varargin{:});
vars = p.Results.vars;
order = getMonomialOrder(p.Results.MonomialOrder);

Lsym = feval_internal(symengine, 'symobj::tolist', L);
vars = feval_internal(symengine, 'symobj::tolist', vars);
Lsym = feval_internal(symengine, 'map', Lsym, 'poly', vars);
B = feval_internal(symengine, 'groebner::gbasis', Lsym, order, 'IgnoreSpecialCases');
B = feval_internal(symengine, 'map', B, 'expr');
B = feval_internal(symengine, 'symobj::tomatrix', B);
B = privResolveOutput(B, L);


