function Y=jacobiCD(U,M)
%jacobiCD   Symbolic Jacobi elliptic function CD.
%   Y = jacobiCD(U,M) returns the Jacobi elliptic function CD,
%   evaluated for each element of U and M.
%
%   See also jacobiAM, jacobiCN, jacobiCS, jacobiDC, jacobiDN, 
%   jacobiDS, jacobiNC, jacobiND, jacobiNS, jacobiSC, jacobiSD, 
%   jacobiSN, jacobiZeta, ELLIPJ, ELLIPKE, ellipticCE, ellipticCK, 
%   ellipticCPi, ellipticE, ellipticF, ellipticK, ellipticNome,
%   ellipticPi.

%   Copyright 2016 The MathWorks, Inc.

Y = privBinaryOp(U, M, 'symobj::vectorizeSpecfunc', 'jacobiCD', 'infinity');
end
