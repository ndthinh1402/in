function f = ihtrans(F,varargin)
%IHTRANS Inverse Hilbert transform.
%   f = IHTRANS(F) is the inverse Hilbert transform of the sym F with
%   default independent variable x.  The default return is a function
%   of t:  F = F(x) => f = f(t).  If F = F(t), then IHTRANS returns a
%   function of u: f = f(u).
%
%   f = IHTRANS(F,s) makes f a function of s instead of the default t.
%
%   f = IHTRANS(F,y,s) takes F to be a function of y instead of the
%   default symvar(F) and returns a function of s:  F = F(y) & f = f(s).
%
%   Examples:
%    syms x s t u f(x)
%    ihtrans(cos(x))  returns  -sin(t)
%    ihtrans(f(x))  returns  -htrans(f(x),x,t)
%    ihtrans(htrans(f(t),t,x),x,s)  returns  f(s)
%
%   See also SYM/HTRANS, SYM/IFOURIER, SYM/ILAPLACE, SYM/IZTRANS, SUBS.

%   Copyright 2018 The MathWorks, Inc.

f = transform('ihilbert', 'x', 't', 'u', F, varargin{:});
end