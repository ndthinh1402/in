function Y=jacobiND(U,M)
%jacobiND   Symbolic Jacobi elliptic function ND.
%   Y = jacobiND(U,M) returns the Jacobi elliptic function ND,
%   evaluated for each element of U and M.
%
%   See also jacobiAM, jacobiCD, jacobiCN, jacobiCS, jacobiDC, 
%   jacobiDN, jacobiDS, jacobiNC, jacobiNS, jacobiSC, jacobiSD, 
%   jacobiSN, jacobiZeta, ELLIPJ, ELLIPKE, ellipticCE, ellipticCK,
%   ellipticCPi, ellipticE, ellipticF, ellipticK, ellipticNome,
%   ellipticPi.

%   Copyright 2016 The MathWorks, Inc.

Y = privBinaryOp(U, M, 'symobj::vectorizeSpecfunc', 'jacobiND', 'infinity');
end
