function F = fibonacci(N)
%FIBONACCI   Symbolic Fibonacci numbers.
%    F = FIBONACCI(N) returns the N-th Fibonacci number.
%    If N is a nonnegative integer then FIBONACCI(N) returns the N-th Fibonacci number.
%    FIBONACCI(N) returns an error if the argument evaluates to a number of wrong type. 
%    FIBONACCI(N) returns the unevaluated function call if N does not evaluate to a number.

%   Copyright 2016 The MathWorks, Inc.

F = privUnaryOp(N, 'symobj::map', 'symobj::fibonacci');
end
