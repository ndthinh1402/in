function Y = cscd(X)
% cscd Cosecant of argument in degrees.
%   cscd(X) is the cosecant of the elements of X, expressed in degrees,
%   for symbolic X.
%
%   See also cscd, sym/acscd, sym/csc, sym/secd.

%   Copyright 2017-2019 The MathWorks, Inc.

planeAngle = [symunit('deg'), symunit('rad'), symunit('arcmin'), symunit('arcsec'), symunit('rev')]; 
if has(X, planeAngle)
    warning(message('symbolic:sym:sym:UnexpectedPlaneAngle', 'csc', 'cscd'));
end
Y = csc(X*sym(pi)/sym('180'));
end