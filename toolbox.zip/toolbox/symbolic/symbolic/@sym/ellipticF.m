function Y=ellipticF(PHI, M)
%ellipticF  Incomplete elliptic integral of the first kind
%   Y = ellipticF(PHI, M) returns the incomplete elliptic integral of the first kind,
%   evaluated for each pair of elements of PHI and M.
%
%   See also SYM/ELLIPKE, SYM/ellipticK, SYM/ellipticE, SYM/ellipticCK, 
%   SYM/ellipticCE, SYM/ellipticPi, SYM/ellipticCPi, SYM/ellipticNome.

%   Copyright 2013-2016 The MathWorks, Inc.
Y = privBinaryOp(PHI, M, 'symobj::vectorizeSpecfunc', 'ellipticF', 'infinity');
end
