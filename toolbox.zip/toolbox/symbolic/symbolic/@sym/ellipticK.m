function Y=ellipticK(M)
%ellipticK  Complete elliptic integral of the first kind
%   Y = ellipticK(M) returns the complete elliptic integral of the first kind,
%   evaluated for each element of M.
%
%   See also SYM/ELLIPKE, SYM/ellipticE, SYM/ellipticCK, SYM/ellipticCE,
%   SYM/ellipticF, SYM/ellipticPi, SYM/ellipticCPi, SYM/ellipticNome.

%   Copyright 2013-2016 The MathWorks, Inc.

Y = privUnaryOp(M, 'symobj::vectorizeSpecfunc', 'ellipticK', 'infinity');
end
