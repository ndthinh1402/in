function Y=ellipticE(PHI, M)
%ellipticE  Elliptic integral of the second kind
%   Y = ellipticE(M) returns the complete elliptic integral of the second kind,
%   evaluated for each element of M.
%
%   Y = ellipticE(PHI, M) returns the incomplete elliptic integral of the second kind,
%   evaluated for each pair of elements of PHI and M.
%
%   See also SYM/ELLIPKE, SYM/ellipticK, SYM/ellipticCK, SYM/ellipticCE,
%   SYM/ellipticF, SYM/ellipticPi, SYM/ellipticCPi, SYM/ellipticNome.

%   Copyright 2013-2016 The MathWorks, Inc.

if nargin == 1 
    Y = privUnaryOp(PHI, 'symobj::vectorizeSpecfunc', 'ellipticE', 'infinity');
else
    Y = privBinaryOp(PHI, M, 'symobj::vectorizeSpecfunc', 'ellipticE', 'infinity');
end
end
