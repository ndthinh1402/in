function [a, m] = factorIntegerPower(n)
%factorIntegerPower   Rewrite integer as power with maximal exponent
%   [A, M] = factorIntegerPower(N) returns positive integers A, M with 
%   N = A^M and such that M is maximal.
%
%   Examples:
%      factorIntegerPower(sym(9))
%      ans =
%         [3, 2]
%
%      factorIntegerPower(sym(7))
%      ans =
%         [7, 1]
%
%   See also FACTOR. 


%   Copyright 2017 The MathWorks, Inc.


nsym = privResolveArgs(n);
nsym = formula(nsym{1});

res = feval_internal(symengine, 'symobj::map', nsym, 'symobj::factorIntegerPower');
asym = feval_internal(symengine, 'symobj::map', res, 'op', 1);
msym = feval_internal(symengine, 'symobj::map', res, 'op', 2);

a = privResolveOutput(asym, n);
m = privResolveOutput(msym, n);
