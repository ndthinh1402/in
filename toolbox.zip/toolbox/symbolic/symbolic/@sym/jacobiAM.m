function Y=jacobiAM(U,M)
%jacobiAM   Symbolic Jacobi amplitude function AM.
%   Y = jacobiAM(U,M) returns the Jacobi amplitude function AM,
%   evaluated for each element of U and M.
%
%   See also jacobiCD, jacobiCN, jacobiCS, jacobiDC, jacobiDN, 
%   jacobiDS, jacobiNC, jacobiND, jacobiNS, jacobiSC, jacobiSD, 
%   jacobiSN, jacobiZeta, ELLIPJ, ELLIPKE, ellipticCE, ellipticCK, 
%   ellipticCPi, ellipticE, ellipticF, ellipticK, ellipticNome,
%   ellipticPi. 

%   Copyright 2016 The MathWorks, Inc.

Y = privBinaryOp(U, M, 'symobj::vectorizeSpecfunc', 'jacobiAM', 'infinity');
end
