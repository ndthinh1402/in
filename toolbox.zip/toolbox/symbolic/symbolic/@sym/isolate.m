function S = isolate(eq, expr)
%ISOLATE  Isolate variable or expression from equation.
%   S = ISOLATE(eq, expr)
%
%   ISOLATE(eq, expr) rearranges the equation 'eq' so that the expression 
%   'expr' appears on the left side. The result is similar to solving 'eq'
%   for 'expr'. However, ISOLATE returns only one solution even if multiple
%   solutions exist. If ISOLATE cannot isolate 'expr' from 'eq', it moves 
%   all terms containing 'expr' to the left side. You can use the output of
%   ISOLATE as input to SUBS to eliminate 'expr' from 'eq'.
%
%   If 'eq' has no solution, ISOLATE returns an error. The ISOLATE function
%   also ignores special cases. If the only solutions to 'eq' are special 
%   cases, then ISOLATE ignores those special cases and returns an error. 
%   Additionally, if the solution returned contains parameters, the 
%   parameters might not be valid for special cases.
%
%   You cannot specify 'expr' as a mathematical constant such as 'pi' and 
%   so on.
%
%   By default, ISOLATE(eq, expr) returns only solutions consistent with 
%   the assumptions on variables in 'expr'.
%
%   If the input contains VPA floating-point numbers, the solver replaces
%   them by approximate rational values. The accuracy of these approximate 
%   values depends on the current variable-precision accuracy (DIGITS).
%   If ISOLATE finds a solution, it converts all numbers back to floating-
%   point numbers, and then returns the result.
%
%   Example 1:
%      syms a b c x
%      eqn = a*x^2 + b*x + c == 0;
%      xSol = isolate(eqn, x)  returns
%      xSol =
%           x = -(b + (b^2 - 4*a*c)^(1/2))/(2*a)
%
%      syms x(t)
%      isolate(a*x(t)^2 + b*c == 0, x(t))  returns
%      ans =
%          x(t) == ((-b)^(1/2)*c^(1/2))/a^(1/2)
%
%      isolate(a*x(t)^2 + b*c == 0, a*x(t))  returns
%      ans =
%          a*x(t) == -(b*c)/x(t)
%
%      isolate(x == x+a, x)  returns
%          Error using sym/isolate (line 106)
%          Unable to isolate x because the equation has no solution.
%
%   Example 2:
%      syms x
%      isolate(cos(x) == x, x)  returns
%      ans =
%          cos(x) - x == 0
%
%      isolate(x^2 == 1, x)  returns
%      ans =
%          x == 1
%
%      isolate(sin(x) == 0, x)  returns
%      ans =
%          x == 0
%
%      syms C
%      isolate(sqrt(x) == C, x)  returns
%      ans =
%          x == C^2
%
%   Example 3:
%      syms x
%      assume(x < 0)
%      isolate(x^4 == 1, x)  returns
%      ans =
%          x == -1
%
%      assume(x, 'clear')
%      isolate(x^4 == 1, x)  returns
%      ans =
%          x == 1
%
%   Example 4:
%      syms x
%      S = isolate(x^3 + 3*x + 1 == 0, x)  returns
%      S =
%          x == root(z^3 + 3*z + 1, z, 1)
%      vpa(S)
%      ans = 
%          x == -0.32218535462608559291147071070403
%
%      isolate(x^3 + vpa(3)*x + vpa(1) == vpa(0), x)  returns
%      ans =
%         x == -0.32218535462608559291147071070403
%
%   Example 5:
%      syms a x
%      isolate(a*x^2/(x-a) == 1, x)  returns
%      ans =
%          x == ((-(2*a - 1)*(2*a + 1))^(1/2) + 1)/(2*a)
%
%   See also VPA, LHS, LINSOLVE, VPASOLVE, RHS, SOLVE, SUBS.

%   Copyright 2016 The MathWorks, Inc.

try
    % the work is done by the MuPAD function isolate       
    S = feval_internal(symengine, 'isolate', eq, expr);
catch CaughtMException
    throw(CaughtMException);
end    
end
