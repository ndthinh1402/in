function Y = cospi(X)
% cospi Compute cos(X*pi) accurately.
%
%   See also cos, sym/cos, sym/cosd.

%   Copyright 2018-2019 The MathWorks, Inc.

Y = cos(X*sym(pi));
end