function Y=jacobiSN(U,M)
%jacobiSN   Symbolic Jacobi elliptic function SN.
%   Y = jacobiSN(U,M) returns the Jacobi elliptic function SN,
%   evaluated for each element of U and M.
%
%   See also jacobiAM, jacobiCD, jacobiCN, jacobiCS, jacobiDC, 
%   jacobiDN, jacobiDS, jacobiNC, jacobiND, jacobiNS, jacobiSC, 
%   jacobiSD, jacobiZeta, ELLIPJ, ELLIPKE, ellipticCE, ellipticCK,
%   ellipticCPi, ellipticE, ellipticF, ellipticK, ellipticNome,
%   ellipticPi.

%   Copyright 2016 The MathWorks, Inc.

Y = privBinaryOp(U, M, 'symobj::vectorizeSpecfunc', 'jacobiSN', 'infinity');
end
