function Y=jacobiCN(U,M)
%jacobiCN   Symbolic Jacobi elliptic function CN.
%   Y = jacobiCN(U,M) returns the Jacobi elliptic function CN,
%   evaluated for each element of U and M.
%
%   See also jacobiAM, jacobiCD, jacobiCS, jacobiDC, jacobiDN, 
%   jacobiDS, jacobiNC, jacobiND, jacobiNS, jacobiSC, jacobiSD, 
%   jacobiSN, jacobiZeta, ELLIPJ, ELLIPKE, ellipticCE, ellipticCK,
%   ellipticCPi, ellipticE, ellipticF, ellipticK, ellipticNome,
%   ellipticPi.

%   Copyright 2016 The MathWorks, Inc.

Y = privBinaryOp(U, M, 'symobj::vectorizeSpecfunc', 'jacobiCN', 'infinity');
end
