function Z = hurwitzZeta(N, S, A)
%HURWITZZETA Symbolic Hurwitz zeta function.
%   Z = hurwitzZeta(S,A) computes the Hurwitz zeta function
%   for each element of the complex arrays S and A.
%
%   Z = hurwitzZeta(N,S,A) computes the Nth derivative of
%   the Hurwitz zeta function with respect to S.
%
%   The Hurwitz zeta function is defined as:
%      hurwitzZeta(S,A) = symsum(1/(K+A)^S,K,0,inf),
%   for real(S)>1 and nonzero (K+A).
%
%   Examples:
%      syms s
%      hurwitzZeta(s,1)  returns  zeta(s)
%      hurwitzZeta(vpa(2),3) returns value with the default 32 digits of precision
%
%   See also zeta.

%   Copyright 2018 The Mathworks, Inc.

narginchk(2, 3);
if nargin == 2
    A = S;
    S = N;
    N = sym(0);
end

Z = privTrinaryOp(N, S, A, 'symobj::vectorizeSpecfunc', 'symobj::hurwitzZeta', 'undefined');

end
