function d = det(A, varargin)
%DET    Symbolic matrix determinant.
%   DET(A) is the determinant of the symbolic matrix A.
%
%   Examples:
%       syms a b c d;
%       det([a b;c d]) returns a*d-b*c
%       choose algorithm,
%       det([a b;c d], 'Algorithm', 'minor-expansion')

%   Copyright 2013-2018 The MathWorks, Inc.

narginchk(1,3);

p = inputParser;
p.addRequired('A', @(x) isa(x,'sym'));
p.addParameter('Algorithm', 'default');
p.parse(A, varargin{:});
A = p.Results.A;
method = validatestring(p.Results.Algorithm, {'minor-expansion', 'default'});

sz = size(formula(A));
if sz(1)~=sz(2)
    error(message('symbolic:det:SquareMatrix'));
end
if strcmp(method, 'default')
	d = privUnaryOp(A, 'symobj::det');
else
	d = privUnaryOp(A, 'symobj::det', 'MinorExpansion');
end

end
