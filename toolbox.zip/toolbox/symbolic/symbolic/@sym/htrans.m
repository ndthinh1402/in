function f = htrans(F,varargin)
%HTRANS Hilbert transform.
%   f = HTRANS(F) is the Hilbert transform of the sym F with
%   default independent variable t.  The default return is a function
%   of x:  F = F(t) => f = f(x).  The Hilbert transform
%   is defined as:
%   int(F(t)/(x-t), t,[-inf, inf], 'PrincipalValue', true)/pi
%   If F = F(x), then HTRANS returns a function of v: f = f(v).
%
%   f = HTRANS(F,s) makes f a function of s instead of the default x.
%
%   f = HTRANS(F,y,s) takes F to be a function of y instead of the
%   default symvar(F) and returns a function of s:  F = F(y) & f = f(s).
%
%   Examples:
%    syms x y t s f(t)
%    htrans(sin(t))  returns  -cos(x)
%    htrans(1/(s^2+1),s,x)  returns  x/(x^2+1)
%    htrans(ihtrans(f(x),x,t),t,y)  returns  f(y)
%
%   See also SYM/IHTRANS, SYM/ZTRANS, SYM/LAPLACE, SYM/FOURIER, SUBS.

%   Copyright 2018-2019 The MathWorks, Inc.

f = transform('hilbert', 't', 'x', 'v', F, varargin{:});
end
