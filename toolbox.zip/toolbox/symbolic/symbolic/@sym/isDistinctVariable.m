function B = isDistinctVariable(x)
% This function is undocumented and will change in a future release

%  isDistinctVariable(x)
%
%  Static hidden sym method to check if the argument is a symbolic variable
%  or a list of symbolic variables and that a list has distinct elements.

%   Copyright 2018 The MathWorks, Inc.
B = logical(feval_internal(symengine, 'symobj::isAllDistinctVars', x));
end
