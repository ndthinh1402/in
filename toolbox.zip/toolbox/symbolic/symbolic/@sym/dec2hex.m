function S = dec2hex(D,varargin)
%DEC2HEX Convert symbolic decimal integer to its hexadecimal representation
%   dec2hex(D) returns a character array where each row is the
%   hexadecimal representation of each decimal integer in D.
%   D must contain non-negative integers.
%
%   dec2hex(D,N) produces a character array where each row
%   represents a hexadecimal number with at least N digits.
%
%   Example:
%      dec2hex(sym(2748)) returns 'ABC'.
%
%   See also SYM/DEC2BIN, STR2SYM, SYM.

%   Copyright 2019 The MathWorks, Inc.

narginchk(1,2);
try
    S = dec2number(16,D,varargin{:});
catch ME
    error(ME.identifier,ME.message);
end
