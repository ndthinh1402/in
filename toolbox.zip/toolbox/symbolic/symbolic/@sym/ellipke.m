function [K,E]=ellipke(M)
%ELLIPKE Complete elliptic integrals of the first and second kind
%  [K,E] = ellipke(M) returns the complete elliptic integrals of the first
%   and second kinds, evaluated for each element of M.
%
%  See also SYM/ellipticE, SYM/ellipticK.

%   Copyright 2013-2016 The MathWorks, Inc.

K = ellipticK(M);
if nargout > 1
    E = ellipticE(M);
end
end
