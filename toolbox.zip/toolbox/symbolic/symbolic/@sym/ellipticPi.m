function Y=ellipticPi(N, PHI, M)
%ellipticPi  Elliptic integral of the third kind
%   Y = ellipticPi(N, M) returns the complete elliptic integral of the 
%   third kind, evaluated for each pair of elements of N and M.
%
%   Y = ellipticPi(N, PHI, M) returns the incomplete elliptic integral 
%   of the third kind, evaluated for each three-tuple of elements of 
%   N, PHI and M.
%
%   See also SYM/ELLIPKE, SYM/ellipticK, SYM/ellipticE, SYM/ellipticCK, 
%   SYM/ellipticCE, SYM/ellipticF, SYM/ellipticCPi, SYM/ellipticNome.

%   Copyright 2013-2016 The MathWorks, Inc.

if nargin == 2
    Y = privBinaryOp(N, PHI, 'symobj::vectorizeSpecfunc', 'ellipticPi', 'infinity');
else
    Y = privTrinaryOp(N, PHI, M, 'symobj::vectorizeSpecfunc', 'ellipticPi', 'infinity');
end
end
