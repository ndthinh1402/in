function B = isSymType(EX,T,TPARAM)
%isSymType     Determine if a symbolic object is of a specified type.
%   B = isSymType(EX,T,<TPARAM>) returns true if symbolic object EX is of type
%   T. Somes types T require an additional parameter TPARAM.
%
%   Examples:
%     syms x(t) s
%
%     isSymType(x,"expression")                 => 1
%     isSymType(x,"symfun")                     => 1
%     isSymType(x,"symfunOf",t)                 => 1
%     isSymType(x,"symfunOf",s)                 => 0
%     isSymType(t,"variable")                   => 1
%     isSymType(x,"x")                          => 1 % x is "symfun"
%     isSymType(t,"t")                          => 0 % t is "variable"
%     isSymType([1,1/2,vpa(1.2),1i],"number")   => [1, 1, 1, 1]
%     isSymType([1,1/2,vpa(1.2),1i],"real")     => [1, 1, 1, 0]
%     isSymType([1,1/2,vpa(1.2),1i],"complex")  => [0, 0, 0, 1]
%     isSymType([1,1/2,vpa(1.2),1i],"constant") => [1, 1, 1, 1]
%     isSymType(x+1,"expression")               => 1
%     isSymType(x+1,"plus")                     => 1
%     isSymType(x==1,"equation")                => 1
%     isSymType(x==1,"eq")                      => 1
%     isSymType([x,1],"symfun")                 => [1,0]
%     isSymType([x(t),1],"symfun")              => [1,0]
%     isSymType([x,1], "symfun")                => [1,0]
%     isSymType([x,1], "x")                     => [1,0]
%     isSymType(diff(x), "expression")          => 1
%     isSymType(diff(x), "diff")                => 1
%
%   See also: SYM/FINDSYMTYPE, SYM/HASSYMTYPE, SYM/MAPSYMTYPE, SYM/SYMFUNTYPE, SYM/SYMTYPE.

%   Copyright 2018 MathWorks, Inc.

narginchk(2,3);
if ischar(T)
    T = string(T);
end
if ~isStringScalar(T)
    error(message("symbolic:symtype:SecondArgMustBeTypeString"));
end
if isa(EX,"symfun")
    EX = formula(EX);
end
if ~isa(EX, "sym")
    error(message("symbolic:symtype:FirstArgMustBeSym"));
end
try
    if feval_internal(symengine, "symobj::islistyAndUnsupported", EX)
        B = strcmp(T, "unsupported");
        return;
    end
    if nargin == 2
        B = privUnaryOp(EX, 'symobj::map', 'symobj::isSymType', """" + T + """");
    else
        if ~isa(TPARAM,'sym')
            TPARAM = sym(TPARAM);
        end
        B = privUnaryOp(EX, 'symobj::map', 'symobj::isSymType', """" + T + """", TPARAM.s);
    end
    B = logical(B);
catch Exception
    throw(Exception);
end
end