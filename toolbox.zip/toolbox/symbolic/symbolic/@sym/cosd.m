function Y = cosd(X)
% cosd Cosine of argument in degrees.
%   cosd(X) is the cosine of the elements of X, expressed in degrees, 
%   for symbolic X.
%
%   See also cosd, sym/acosd, sym/cos, sym/sind, sym/tand.

%   Copyright 2017-2019 The MathWorks, Inc.

planeAngle = [symunit('deg'), symunit('rad'), symunit('arcmin'), symunit('arcsec'), symunit('rev')]; 
if has(X, planeAngle)
    warning(message('symbolic:sym:sym:UnexpectedPlaneAngle', 'cos', 'cosd'));
end
Y = cos(X*sym(pi)/sym('180'));
end