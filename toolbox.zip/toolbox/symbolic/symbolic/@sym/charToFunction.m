function f = charToFunction(c)
%CHARTOFUNCTION(C)
%   Returns an array of MuPAD variables that correspond to the function c.
%   This is a hidden static method of the sym class.
%
%   Examples:
%   charToFunction('int') returns the MuPAD identifiers [int, int_Var]
%   syms D(x), charToFunction('D') returns [D, D_Var]

%   Copyright 2016 The MathWorks, Inc.

% Names that have to be translated in a special way
specialnames = containers.Map(...
    {'angle', 'ei', 'expint', 'in',  'log', 'symsum', 'symprod'},...
    {'arg',   'Ei', 'Ei'    , '_in', 'ln',  'sum',    'product'});


if iscell(c)
   f = cellfun(@sym.charToFunction, c, 'UniformOutput', false);
   % denest the cell array of sym vectors using cell2sym
   f = unique(cell2sym(f));
   return;
end

if ~isvarname(c)
    error(message('symbolic:sym:errmsg1'))
end

% use the standard conversion convertName
g = sym(c);

% convert to function
% re-name MATLAB names to MuPAD names
if isKey(specialnames, c)
    c = specialnames(c);
end
% Do not rename the function name c to c_Var
% Beware of MuPAD keywords
h = evalin_internal(symengine, ['`' c '`']);
f = unique([g, h]);
