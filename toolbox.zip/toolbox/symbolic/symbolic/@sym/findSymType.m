function R = findSymType(EX,T,TPARAM)
%findSymType     Returns subexpressions of a specified type.
%   R = findSymType(EX,T,<TPARAM>) returns a vector of all subexpressions E of
%   EX with E of type T. Somes types T require an additional parameter TPARAM.
%   R can be empty.
%
%   Examples:
%     syms x(t) s
%
%     findSymType(x+1,"symfun")                     => x(t)
%     findSymType(x+1,"symfunOf",t)                 => x(t)
%     findSymType(x+1,"symfunOf",s)                 => []
%     findSymType(x+1,"x")                          => x(t)
%     findSymType(x+1,"t")                          => []
%     findSymType(t+1,"variable")                   => t
%     findSymType([1,1/2,vpa(1.2),1i],"number")     => [1/2, 1, 1.2, 1i]
%     findSymType([1,1/2,vpa(1.2),1i],"real")       => [1/2, 1, 1.2]
%     findSymType([1,1/2,vpa(1.2),1i],"complex")    => 1i
%     findSymType([1,1/2,vpa(1.2),1i],"variable")   => []
%     findSymType(x+1,"plus")                       => x(t) + 1
%     findSymType(x==1,"constant")                  => 1
%     findSymType(x==1,"variable")                  => t
%     findSymType(x+2*diff(x)+3*diff(x,t,t),"diff") => [diff(x(t),t), diff(x(t),t,t)]
%
%   See also: SYM/HASSYMTYPE, SYM/ISSYMTYPE, SYM/MAPSYMTYPE, SYM/SYMFUNTYPE, SYM/SYMTYPE.

%   Copyright 2018 MathWorks, Inc.

narginchk(2,3);
if ischar(T)
    T = string(T);
end
if ~isStringScalar(T)
    error(message("symbolic:symtype:SecondArgMustBeTypeString"));
end
if isa(EX,"symfun")
    EX = formula(EX);
end
if ~isa(EX, "sym")
    error(message("symbolic:symtype:FirstArgMustBeSym"));
end
try
    if nargin == 2
        R = feval_internal(symengine, 'symobj::findSymType', EX, """" + T + """");
    else
        if ~isa(TPARAM,'sym')
            TPARAM = sym(TPARAM);
        end
        R = feval_internal(symengine, 'symobj::findSymType', EX, """" + T + """", TPARAM.s);
    end
catch Exception
    throw(Exception);
end
end