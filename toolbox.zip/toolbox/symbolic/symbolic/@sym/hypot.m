function Z = hypot(X, Y)
%HYPOT Symbolic hypot function

%   Copyright 2016 The MathWorks, Inc.

Z =  privBinaryOp(X, Y, 'symobj::zipWithImplicitExpansion', 'symobj::hypot');
end
