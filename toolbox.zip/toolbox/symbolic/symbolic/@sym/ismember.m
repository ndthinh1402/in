function [lia, locb] = ismember(A, B, varargin)
%ISMEMBER  Symbolic ismember function.

%   Copyright 2012-2018 The MathWorks, Inc.

narginchk(2,4);
nrhs = nargin - 2;

varargin = sym.convertStrings(varargin);

% Checking of flags taken from method for doubles, to generate consistent error messages.
% Acceptable combinations, with optional inputs denoted in []:
% ismember(A,B, ['rows'], ['legacy'/'R2012a'])
nflagvals = 3;
flagvals = {'rows' 'legacy' 'R2012a'};
% When a flag is found, note the index into varargin where it was found
flaginds = zeros(1,nflagvals);
for i = 1:nrhs
    flag = varargin{i};
    foundflag = matlab.internal.math.partialMatchString(flag,flagvals);
    if ~any(foundflag)
        if ischar(flag)
            error(message('MATLAB:ISMEMBER:UnknownFlag',flag));
        else
            error(message('MATLAB:ISMEMBER:UnknownInput'));
        end
    end
    % Only 1 occurrence of each allowed flag value
    if flaginds(foundflag)
        error(message('MATLAB:ISMEMBER:RepeatedFlag',flag));
    end
    flaginds(foundflag) = i;
end

% Only 1 of each of the paired flags
if flaginds(2) && flaginds(3)
    error(message('MATLAB:ISMEMBER:BehaviorConflict'))
end
% 'legacy' and 'R2012a' flags must be trailing
if flaginds(2) && flaginds(2)~=nrhs
    error(message('MATLAB:ISMEMBER:LegacyTrailing'))
end
if flaginds(3) && flaginds(3)~=nrhs
    error(message('MATLAB:ISMEMBER:R2012aTrailing'))
end

rowflag = logical(flaginds(1));
legacyflag = logical(flaginds(2));
% We can ignore the R2012a flaginds(3). 

% The only relevant effect of legacy is that we search backwards.
% Convert legacy flag to a MuPAD boolean.
backwards = feval_internal(symengine, 'symobj::equal2', legacyflag, true);

if ~rowflag
    if isscalar(B)
        lia = logical(A == B);
        locb = double(lia);
    else
        locb = double(feval_internal(symengine, 'symobj::map', A, 'symobj::ismemberScalar', B, backwards));
        lia = locb ~= 0;
    end
    
else    % 'rows' case
    if ~(ismatrix(A) && ismatrix(B))
        error(message('MATLAB:ISMEMBER:NotAMatrix'));
    end
    
    [rowsA,colsA] = size(A);
    [rowsB,colsB] = size(B);
    
    if colsA ~= colsB
        error(message('MATLAB:ISMEMBER:AandBColnumAgree'));
    end
    
    % Empty check for 'rows'.
    if rowsA == 0 || rowsB == 0
        lia = false(rowsA,1);
        locb = zeros(rowsA,1);
        return
    end
    
    if isscalar(B)
        lia = logical(A == B);
        locb = double(lia);
    else
        locb = double(feval_internal(symengine, 'symobj::mapRows', A, 'symobj::ismemberRow', B, backwards));
        lia = locb ~= 0;
    end
    
end
end
