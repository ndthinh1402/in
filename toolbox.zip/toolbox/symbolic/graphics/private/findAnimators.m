function F = findAnimators(fig)
%findAnimators Vector of all valid animators in a given figure
%    F = findAnimators(fig) 
%    returns the vector of all valid animators in fig.
%    F = findAnimators([])
%    returns [].

%   Copyright 2018 The MathWorks, Inc.

if isempty(fig)
   F = [];
else
   F = findobj(fig, '-class', 'matlab.graphics.function.Animator');    
end

if ~isempty(F)
    % delete all animators whose objects are deleted handles
    F = F(isValidAnimator(F));
end    

end