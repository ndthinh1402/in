function [timeMin, timeMax, frameRate] = commonRange(F, userTimeRange, userFrameRate)
%commonRange Common range and time step of an array of animators.
%   [timeMin, timeMax, timeStep] = commonRange(F, userFrameRate)
%   returns the start time, end time, and increment to use when
%   playing/writing/converting the array of animators F with a given
%   userTimeRange and userFrameRate. 
%   If the time range or frame rate are NaN, the outputs are computed 
%   from the time ranges or frame rates of the animators in F. 

%   Copyright 2018 The MathWorks, Inc.

% use the maximum number of frames per second among all objects
if isnan(userFrameRate)
    frameRate = max([F.FrameRate]);
else
    frameRate = userFrameRate;
end    
% use earliest start time
if isnan(userTimeRange)
    startTimes = startTime(F);
    timeMin = min(startTimes(:));
    endTimes = endTime(F);
    timeMax = max(endTimes(:));
else
    timeMin = userTimeRange(1);
    timeMax = userTimeRange(2);
end

end