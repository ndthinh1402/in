function A = fanimator(varargin)
%fanimator Create an Animator object.
%   A = fanimator(funchandle)
%   creates an animated graphics object whose properties at time t0 equal
%   funchandle(t0) with default time span t0 from 0 to 10.
%   The object funchandle must be a function of one variable.
%   See Example 2 for more details.
%
%   A = fanimator(funchandle, furtherargs, 'AnimationParameter', y)
%   creates an animated graphics object whose properties at time t0 equal
%   funchandle(subs(furtherargs, y, t0)).
%   If omitted, the animation parameter equals sym('t') by default.
%
%   A = fanimator(..., 'AnimationRange', [timeBegin timeEnd])
%   lets the time t0 vary from timeBegin to timeEnd. 
%
%   A = fanimator(..., 'FrameRate', n)
%   generates n frames per unit time.
%
%   A = fanimator(ax, ...)
%   creates an animated graphics object in the axes ax.
%
%   Example 1 - Animation for plotting a quadratic function.
%       syms t
%       fanimator(@plot, t, t^2, '*')
%       playAnimation
%
%   Example 2 - Animation for plotting a sinusoidal curve.
%       fanimator(@(t) plot(t, sin(t), 'r*'))
%       playAnimation
%
%   Example 3 - Animation for plotting a circle parameterized by variable x.
%       The unit circle has a center coordinate (t, 1) which moves from (0,1) to (10,1).
%       syms t x
%       fanimator(@fplot, cos(x) + t, sin(x) + 1, [0 2*pi], 'AnimationRange', [0, 10]);
%       playAnimation
%      
%   See also animationToFrame, playAnimation, writeAnimation.

%   Copyright 2018 The MathWorks, Inc.

narginchk(1, inf);
if isa(varargin{1}, 'matlab.graphics.Graphics')
    ax = varargin{1};
    F = varargin{2};
    varargin = varargin(3:end);
    validateattributes(ax, {'matlab.ui.control.UIAxes', 'matlab.graphics.axis.Axes'}, {});
else
    ax = gobjects(0);
    F = varargin{1};
    varargin = varargin(2:end);
end

validateattributes(F, {'function_handle'}, {});
ax = newplot(ax);

% Argument checking:
% split varargin into name-value pairs specific to the animation, 
% and other arguments
k = 1; 
while k <= numel(varargin) && ~isAnimationOption(varargin{k})
    k = k+1;
end
% arguments to pass to F
args = varargin(1:k-1);

% use inputParser to parse the name-value pairs
p = inputParser;
% We allow that function arguments come after the animation-specific
% name-value pairs. To change this, set KeepUnmatched to false
p.KeepUnmatched = true;
addParameter(p, 'AnimationRange', [0, 10], @matlab.graphics.function.internal.checkRangeVector);
addParameter(p, 'AnimationParameter', NaN, @(x) isa(x, 'sym'));
addParameter(p, 'FrameRate', 10, @(X) isreal(X) && X>0);
parse(p, varargin{k:end});
trange = p.Results.AnimationRange;

amin = trange(1);
amax = trange(2);
animationParameter = p.Results.AnimationParameter;
if isnan(animationParameter) && ~isempty(args)
    % F is called with additional args, depending on the animation
    % parameter. Thus an animation parameter must be defined, and the
    % symbolic engine must be initialized in this case
    animationParameter = sym('t');
end
FPS = p.Results.FrameRate;
% add the unmatched parameters as name-value pairs to the call
FF = fieldnames(p.Unmatched);
for k = 1:numel(FF)
    args(end+1:end+2)= {FF{k}, p.Unmatched.(FF{k})};
end

% create (amax-amin)*FPS + 1 frames
% e.g., for amin = 0, amax = 2, FPS = 10, we generate 21 frames
% which correspond to times 0, 0.1, ..., 1.9, 2.0
times = amin: 1/FPS : amax;

% get those properties of the axes that might be modified by adding the object
axesFieldnames = ["ColorOrderIndex", "LineStyleOrderIndex"];
for fieldn = axesFieldnames
    axesState.(fieldn) = ax.(fieldn);
end

% Initialize invisible figure
oldFig = get(groot, 'CurrentFigure');
if ~isempty(oldFig)
    cleanUpObj1 = onCleanup(@() figure(oldFig));
end
[invisibleFigure, newax] = initInvisibleFigure(ax);
cleanUpObj2 = onCleanup(@() delete(invisibleFigure)); 

% Create the changing object (state at initial time)
set(groot, 'CurrentFigure', invisibleFigure);
if isempty(args)
    % interpret F as a function of time
    staticObject = F(amin);
else
    args0 = cellfun(@(a) evalAt(a, animationParameter, amin), args, ...
        'UniformOutput', false);
    staticObject = F(args0{:});
end
% We need the following test because isgraphics(0) == true
if ~isa(staticObject, 'matlab.graphics.Graphics')
    error(message('symbolic:fanimator:MustReturnGraphicsObject'));
end
staticObject.Parent = ax;

% Exclude some properties that are never animatable
animatableProperties = setdiff(fieldnames(set(staticObject)), ...
    {'Parent' 'DimensionNames' 'DimensionNamesMode' 'BusyAction' 'Children' ...
     'CreateFcn' 'DeleteFcn' 'HitTest' 'Interruptible' 'PickableParts' ...
     'Selected' 'SelectionHighlight' 'Tag' 'UIContextMenu' 'ButtonDownFcn' ...
     'HandleVisibility' 'UserData'});
    
[XLim, YLim, ZLim] = deal([NaN, NaN]);

[changingProperties, props] = precompute(times);

anim = matlab.graphics.function.Animator(changingProperties, props, FPS, trange);
anim.Parent = ax;
staticObject.Parent = anim;
AD = matlab.graphics.function.AnimationAxesData(XLim, YLim, ZLim);
AD.Parent = anim;
if nargout >= 1
    A = anim; 
end
drawnow

% local functions

    function [invFig, newax] = initInvisibleFigure(visibleAxes)
        % Initialize the invisible figure in which the precomputing takes
        % place
        invFig = figure('Visible', 'off', ...
            'IntegerHandle', 'off', ...
            'Tag', 'InvisFigure');
        realax = findAbstractAxes(visibleAxes);
        newax = copyobj(realax, invFig);
        invFig.CurrentAxes = newax;
    end

    function [changingProp, props] = precompute(timeVec)
        % create a cell array props such that props{k} contains the properties
        % of the object during the k-th frame at time timeVec(k)
        props = cell(size(timeVec));
        initialValues = get(staticObject, animatableProperties);
        % changing: vector of logical values. Equals 1 at those positions where a
        % property attains different values, and 0 where it remains constant.
        changing = false;
        
        for frameno = 1:numel(timeVec)
            % work with the properties the axes had before adding the static object
            for field = axesFieldnames
                newax.(field) = axesState.(field);
            end
            if ~isempty(args)
                args0 = cellfun(@(a) evalAt(a, animationParameter, timeVec(frameno)), args, ...
                    'UniformOutput', false);
                currentObject = F(args0{:});
            else
                currentObject = F(timeVec(frameno));
            end
            % check that everything is in order
            if ~isequal(class(currentObject), class(staticObject))
                error(message('symbolic:fanimator:NotSameClass'));
            end
            currentValues = get(currentObject, animatableProperties);
            % which of them are different from the initial values?
            chg = ~cellfun(@isequal, initialValues, currentValues);
            changing = changing | chg;
            props{frameno} = currentValues;
            updateAxesLimits(ancestor(currentObject, 'axes'));
            % delete the object, to avoid increasing ColorOrderIndex etc. 
            if ~isequal(currentObject, staticObject)
              delete(currentObject);
            end
        end
 
        % select those properties that are indeed changing
        props = cellfun(@(X) X(changing), props, 'UniformOutput', false);
        changingProp = animatableProperties(changing);

        % some graphics command turn Box on. If the animated object has
        % done this to newax, do the same for ax.
        ax.Box = newax.Box;

        delete(newax);
        delete(invisibleFigure);
    end

    function updateAxesLimits(ax)
        % updates XLim, YLim, ZLim using the limits in ax
        XLim = [min(XLim(1), ax.XLim(1)), max(XLim(end), ax.XLim(2))];
        YLim = [min(YLim(1), ax.YLim(1)), max(YLim(end), ax.YLim(2))];
        ZLim = [min(ZLim(1), ax.ZLim(1)), max(ZLim(end), ax.ZLim(2))];
    end

end

function a = evalAt(a, t, t0)
% Evaluate the sym object a at time t=t0
if isa(a, 'sym')
    try
        a = subs(a, t, t0);
    catch
        a = sym(NaN(size(a)));
    end
    if isempty(symvar(a))
        % most graphics functions need doubles
        a = double(a);
    end
end
end

function b = isAnimationOption(s)
   b = (ischar(s) || isstring(s) && isscalar(s)) && ...
       (startsWith(lower(s), 'animationr') || ...
       startsWith(lower(s), 'animationp') || ...
       startsWith('framerate', lower(s)));
end
