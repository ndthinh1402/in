function rewindAnimation(varargin)
%rewindAnimation Rewind animation to starting point. 
%   rewindAnimation 
%   sets the timer of the current figure to its starting point.
%
%   rewindAnimation(fig)
%   does the same for figure fig. 
%
%   Example: 
%      syms t
%      fanimator(@plot, t, t^2, '*')
%      playAnimation
%      rewindAnimation
%
%   See also fanimator, playAnimation.

%   Copyright 2018 The MathWorks, Inc.

p = inputParser;
addOptional(p, 'Figure', get(groot, 'CurrentFigure'), @(fig) isa(fig, 'matlab.ui.Figure'));
parse(p, varargin{:});
fig = p.Results.Figure;

% if there is no figure, there is nothing to rewind
if isempty(fig)
    return;
end

animTimer = matlab.graphics.function.AnimationTimer(fig);
rewind(animTimer);
end