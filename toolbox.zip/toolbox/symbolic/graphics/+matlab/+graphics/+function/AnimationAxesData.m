classdef AnimationAxesData < ...
        matlab.graphics.primitive.Data & ...
        matlab.graphics.mixin.AxesParentable
    %AnimationAxesData
    %   AnimationAxesData(XLim, YLim, ZLim)
    %   creates an object that holds info on the axes limits needed.
    
    %   Copyright 2018 The MathWorks, Inc.
    
    properties(Constant)  
        Type = 'AnimationAxesData';
    end   
    
    properties (SetAccess = 'private')
        XLim;
        YLim;
        ZLim;
    end
    
    methods
        function self = AnimationAxesData(XLim, YLim, ZLim)
            if nargin == 0
              return;
            end  
            self.HandleVisibility = 'off';
            self.XLim = XLim;
            self.YLim = YLim;
            self.ZLim = ZLim;
        end
    end
    
    methods(Hidden)
        function extents = getXYZDataExtents(obj)
            extents = vertcat(obj.XLim, obj.YLim, obj.ZLim);
        end 
    end
    
    methods (Access = protected, Hidden)
        function groups = getPropertyGroups(~)
            % Customize short display.
            props = {
                'XLim',...
                'YLim',...
                'ZLim'
                };
            groups = matlab.mixin.util.PropertyGroup(props);
        end
    end % protected and hidden methods
    
end