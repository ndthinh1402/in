function ineq = optimineq(varargin)
%OPTIMINEQ Create an optimization inequality array
%
%   INEQ = OPTIMINEQ(N) creates an N-by-1 vector of optimization
%   inequalities.
%
%   INEQ = OPTIMINEQ(N1,N2,...) or OPTIMINEQ([N1 N2 ...])
%   creates an N1-by-N2-by-... array of uninitialized optimization
%   inequalities.
%
%   INEQ = OPTIMINEQ(CSTR) creates an array of uninitialized
%   optimization inequalities from the cell array of character vectors or
%   string vector CSTR. INEQ is 1-by-N if CSTR is 1-by-N, otherwise
%   INEQ is N-by-1, where N is the number of elements of CSTR. INEQ can
%   be indexed by the character vectors or strings in CSTR.
%
%   INEQ = OPTIMINEQ(CSTR1,CSTR2,...) or OPTIMINEQ({CSTR1,
%   CSTR2,...}) creates an NCSTR1-by-NCSTR2-by-... array of uninitialized 
%   optimization inequalities. CSTRi is either a cell array of character
%   vectors or a string vector. NCSTRi is the number of character vectors
%   or strings in each input, CSTRi. INEQ can be indexed in the i-th
%   dimension by the character vectors or strings in CSTRi.
%   
%   INEQ = OPTIMINEQ(CSTR1,N2,...) or OPTIMINEQ({CSTR1, N2,...})
%   creates an NCSTR1-by-N2-by-... array of uninitialized optimization
%   inequalities defined by a combination of numeric values and character
%   arrays or stings. CSTRi is either a cell array of character vectors or
%   a string vector. Ni is a double indicating the size of the inequalities
%   in the i-th dimension.
%
%   Examples:
%   % Create a 4-by-1 inequality array
%   ineq1 = optimineq(4)
%
%   % Create a 3-by-2 inequality array
%   ineq2 = optimineq(3, 2)
% 
%   % Create a 1-by-3 inequality array where the columns can be 
%   % indexed by character vectors
%   ineq3 = optimineq({'bos', 'jfk', 'lax'})
% 
%   % Create a 2-by-3 inequality array with character vector indexing
%   % in each direction
%   ineq4 = optimineq({'corn', 'wheat'}, {'bos', 'jfk', 'lax'})
%
%   % Create a 2-by-4-by-3 array with character vector indexing in the
%   % dimensions 1 and 3
%   ineq5 = optimineq({'corn', 'wheat'}, 4, {'bos', 'jfk', 'lax'})

%   See also OPTIMVAR, OPTIMEQ, OPTIMCONSTR

%   Copyright 2019 The MathWorks, Inc.

% Parse inputs
[outNames, outSize, NVpair] = optim.internal.problemdef.formatDimensionInput(varargin);

% There are no valid name value pairs for optimineq. If anyone tries to
% use one, we need to throw a helpful error message.
if ~isempty(NVpair)
    error(message('optim_problemdef:validateIndexNames:InvalidDimensionInput'));
end

% floor size values to zero
outSize(outSize < 0) = 0;

% Forward to inequality constructor
ineq = optim.problemdef.OptimizationInequality(outSize, outNames);
