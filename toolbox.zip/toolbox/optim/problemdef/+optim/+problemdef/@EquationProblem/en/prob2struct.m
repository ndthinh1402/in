%PROB2STRUCT Convert an EquationProblem to solver form.
%
% PROBLEMSTRUCT = PROB2STRUCT(PROB) converts the EquationProblem input
% PROB and returns a structure that contains the solver name, solver
% options and problem description in a form the solver can use.
%
% PROBLEMSTRUCT = PROB2STRUCT(PROB, X0) additionally specifies an initial
% point. X0 is a structure with fieldnames that match the 'Name' property
% of the OptimizationVariables in the problem.
%
% PROBLEMSTRUCT = PROB2STRUCT(___, NAME, VALUE) specifies additional
% options for PROB2STRUCT using one or more name-value pair arguments:
%
% 'Options'               - Options for the solver
% 'EquationFunctionName'  - Name of the generated equation function.
%                           Used in problemStruct.objective.
% 'FileLocation'          - Location for exported objective, constraint and
%                           other required subfunctions.

 
%   Copyright 2019 The MathWorks, Inc.

