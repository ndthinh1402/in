%MAPEXITFLAG Map solver exitflag 
% 
%   EXITFLAG = MAPEXITFLAG(PROB, SOLVERFVAL, EXITFLAG, SOLVER, VARARGIN) maps the
%   exitflag from the solver to reflect the final solution of the problem.

 
%   Copyright 2019 The MathWorks, Inc.

