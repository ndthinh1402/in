classdef EquationProblem< optim.internal.problemdef.ProblemImpl
%EQUATIONPROBLEM Equation problem specification
%
%   EquationProblem contains OptimizationEqualities that constitute an
%   equation problem.
%
%   Use the EQNPROBLEM function to initialize an EquationProblem.
%
%   Construct an EquationProblem with a custom description, for example
%
%   problem = eqnproblem('Description','My Example Problem');
%
%   See also EQNPROBLEM

     
    %   Copyright 2019 The MathWorks, Inc.

    methods
    end
    properties
        Equations;

    end
end
