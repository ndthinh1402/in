%MAPEXITMESSAGE Map solver exitflag and message for equation solving

 
%   Copyright 2019 The MathWorks, Inc.

