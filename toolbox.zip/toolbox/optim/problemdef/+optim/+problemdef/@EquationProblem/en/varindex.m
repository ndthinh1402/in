%VARINDEX Linear indices of problem variables
% 
%   VARINDEX is used to determine the linear indices of the specified
%   variable in a vector containing all named problem variables in
%   solver-based form.
%
%   IND = VARINDEX(P) returns the linear index of all problem variables in
%   a structure. Each field of the structure contains the linear index of a
%   named variable in a vector containing all problem variables in
%   solver-based form.
%
%   IND = VARINDEX(P, VARNAME) returns the linear index of
%   P.VARIABLES.(VARNAME) in a vector containing all named problem
%   variables in solver-based form.

 
%   Copyright 2018-2019 The MathWorks, Inc.

