%SOLVE Solve equation problem
%
% SOL = solve(PROB) solves the specified equation problem. The solution is
% returned as a struct.
%
% SOL = solve(PROB, X0) solves the problem using the specified initial
% point. X0 is a structure with field names that match the 'Name' property
% of the OptimizationVariables in PROB.
%
% SOL = solve(___, NAME, VALUE) specifies additional options for solve
% using one or more name-value pair arguments:
% 
%  'Solver' - Name of the solver to be used (e.g., 'fsolve')
%  'Options' - Options for the solver 
% 
% [SOL,FVAL] = solve(PROB,...) returns the difference between the left and
% right hand sides of the equations at the solution. Note, if
% PROB.EQUATIONS is a struct, FVAL is a struct containing the same field
% names, otherwise it is a double array.
%
% [SOL,FVAL,EXITFLAG] = solve(PROB,...) returns an EXITFLAG that describes
% the exit condition. See the documentation for the possible values of
% EXITFLAG and the corresponding exit conditions.
%
% [SOL,FVAL,EXITFLAG,OUTPUT] = solve(PROB,...) returns additional
% information about the solution provided by the solver in the structure
% OUTPUT. See the documentation for OUTPUT.solver to get a complete
% description.
%
% Example: 
%
%   % Create an equation problem
%   eprob = eqnproblem;
%
%   % Create optimization variables
%   x = optimvar('x');
%   y = optimvar('y');
%
%   % Define the equations
%   eprob.Equations = [...
%      x - y^3 + 5*y^2 - 2*y == 13;...
%      x + y^3 + y^2 - 14*y == 29];
%
%   % Solve the problem
%   x0.x = 6;
%   x0.y = 5;
%   sol = solve(prob, x0);
% 
% See also EQNPROBLEM, OPTIMOPTIONS

     
%   Copyright 2019 The MathWorks, Inc.

