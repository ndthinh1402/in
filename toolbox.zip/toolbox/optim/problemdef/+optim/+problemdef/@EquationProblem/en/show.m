%SHOW Show mathematical display of the problem
%
%   SHOW(PROB) displays a mathematical form of the problem.
%
%   See also OPTIM.INTERNAL.PROBLEMDEF.EQUATIONPROBLEM/WRITE, 
%            OPTIMPROBLEM, EQNPROBLEM

 
%   Copyright 2019 The MathWorks, Inc.

