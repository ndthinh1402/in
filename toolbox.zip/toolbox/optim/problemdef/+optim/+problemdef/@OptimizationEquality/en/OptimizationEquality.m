classdef OptimizationEquality< optim.problemdef.OptimizationConstraint
%OPTIMIZATIONEQUALITY Equalities for optimization and equation problems
%
%   OptimizationEquality contains one or more equality expressions in
%   terms of OptimizationVariables.
%
%   Construct an equality by equating expressions, for example
%
%   x = optimvar('x');
%   y = optimvar('y');
%   c = 2*x + 3*y == 5
%
%   % Create 4 equalities
%   Z = optimvar('Z',4,3);
%   constrsum = sum(Z,2) == 1;
%
%   Use the OPTIMEQ function to create an uninitialized array of
%   OptimizationEquality objects.
%
%   See also OPTIMEQ

     
    %   Copyright 2019 The MathWorks, Inc.

    methods
    end
end
