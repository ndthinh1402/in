% ACOSH  Inverse hyperbolic cosine.
%    ACOSH(X) is the inverse hyperbolic cosine of the elements of X.
% 
%    See also ACOSH

 
%   Copyright 2019 The MathWorks, Inc.

