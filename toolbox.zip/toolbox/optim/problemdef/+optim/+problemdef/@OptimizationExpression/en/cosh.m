% COSH   Hyperbolic cosine.
%    COSH(X) is the hyperbolic cosine of the elements of X.
% 
%    See also COSH

 
%   Copyright 2019 The MathWorks, Inc.

