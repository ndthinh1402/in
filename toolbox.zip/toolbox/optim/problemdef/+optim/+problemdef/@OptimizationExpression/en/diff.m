% DIFF Difference and approximate derivative.
%    DIFF(X), for a vector X, is [X(2)-X(1)  X(3)-X(2) ... X(n)-X(n-1)].
%    DIFF(X), for a matrix X, is the matrix of row differences,
%       [X(2:n,:) - X(1:n-1,:)].
%    DIFF(X), for an N-D array X, is the difference along the first
%       non-singleton dimension of X.
%    DIFF(X,N) is the N-th order difference along the first non-singleton
%       dimension (denote it by DIM). If N >= size(X,DIM), DIFF takes
%       successive differences along the next non-singleton dimension.
%    DIFF(X,N,DIM) is the Nth difference function along dimension DIM.
%       If N >= size(X,DIM), DIFF returns an empty array.
%
%    See also DIFF

 
%   Copyright 2019 The MathWorks, Inc.

