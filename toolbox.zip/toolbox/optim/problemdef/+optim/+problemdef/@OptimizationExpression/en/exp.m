%EXP   Exponential.
%   EXP(X) is the exponential of the elements of X, e to the X.
%
%   See also EXP.

 
%   Copyright 2019 The MathWorks, Inc.

