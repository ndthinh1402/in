% ATANH  Inverse hyperbolic tangent.
%    ATANH(X) is the inverse hyperbolic tangent of the elements of X.
% 
%    See also ATANH

 
%   Copyright 2019 The MathWorks, Inc.

