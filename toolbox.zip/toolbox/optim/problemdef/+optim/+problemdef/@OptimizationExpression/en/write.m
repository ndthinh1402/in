%WRITE Write an OptimizationExpression to a text file
%
%   WRITE(EXPR) writes a simplified mathematical form of the
%   OptimizationExpression into a text file. The file name is the workspace
%   name of the OptimizationExpression EXPR, appended with '.txt'. If
%   WRITE cannot construct the filename from the input expression, it
%   writes to the file 'WriteExprOutput.txt'. WRITE overwrites any
%   existing file.
%
%   WRITE(EXPR, FILENAME) writes a simplified mathematical form of the
%   OptimizationExpression into FILENAME. 
%
%   See also OPTIM.PROBLEMDEF.OPTIMIZATIONEXPRESSION/SHOW, OPTIMEXPR

 
%   Copyright 2019 The MathWorks, Inc.

