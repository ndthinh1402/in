% COS    Cosine of argument in radians.
%    COS(X) is the cosine of the elements of X. 
% 
%    See also COS

 
%   Copyright 2019 The MathWorks, Inc.

