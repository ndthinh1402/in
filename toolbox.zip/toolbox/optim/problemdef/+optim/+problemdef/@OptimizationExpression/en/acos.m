% ACOS   Inverse cosine, result in radians.
%    ACOS(X) is the arccosine of the elements of X.
% 
%    See also ACOS

 
%   Copyright 2019 The MathWorks, Inc.

