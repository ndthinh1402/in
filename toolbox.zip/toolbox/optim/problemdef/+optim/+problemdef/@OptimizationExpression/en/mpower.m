%MPOWER Matrix power of 2D OptimizationExpression array.
%
%   MPOWER(OBJ,B) takes the matrix of OptimizationExpressions OBJ to the
%   power B.
%
%   See also MPOWER, POWER

 
%   Copyright 2017-2018 The MathWorks, Inc.

