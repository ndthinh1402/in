% ASINH  Inverse hyperbolic sine.
%    ASINH(X) is the inverse hyperbolic sine of the elements of X.
% 
%    See also ASINH

 
%   Copyright 2019 The MathWorks, Inc.

