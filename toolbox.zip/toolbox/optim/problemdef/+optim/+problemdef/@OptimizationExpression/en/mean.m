%MEAN   Average or mean value.
%   S = MEAN(X) is the mean value of the elements in X if X is a vector. 
%   For matrices, S is a row vector containing the mean value of each 
%   column. 
%   For N-D arrays, S is the mean value of the elements along the first 
%   array dimension whose size does not equal 1.
%
%   MEAN(X,DIM) takes the mean along the dimension DIM of X.
%
%   See also MEAN.

 
%   Copyright 2018 The MathWorks, Inc.

