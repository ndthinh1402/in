% SINH   Hyperbolic sine.
%    SINH(X) is the hyperbolic sine of the elements of X.
% 
%    See also SINH

 
%   Copyright 2019 The MathWorks, Inc.

