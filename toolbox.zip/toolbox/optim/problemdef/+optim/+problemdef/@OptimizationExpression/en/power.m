%POWER Elementwise power of ND OptimizationExpression array.
%
%   POWER(OBJ,B) takes every entry in the OptimizationExpression array OBJ
%   to the power B.
%
%   See also POWER, MPOWER

 
%   Copyright 2017-2018 The MathWorks, Inc.

