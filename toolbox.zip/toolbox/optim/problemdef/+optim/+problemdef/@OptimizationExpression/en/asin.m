% ASIN   Inverse sine, result in radians.
%    ASIN(X) is the arcsine of the elements of X.
% 
%    See also ASIN

 
%   Copyright 2019 The MathWorks, Inc.

