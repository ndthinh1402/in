%RESHAPE Reshape OptimizationExpression array.
%
%   See also RESHAPE.
