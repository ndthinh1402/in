%SQRT   Sqrt.
%   SQRT(X) is the square root of the elements of X.
%
%   See also SQRT.

 
%   Copyright 2019 The MathWorks, Inc.

