% TANH   Hyperbolic tangent.
%    TANH(X) is the hyperbolic tangent of the elements of X.
% 
%    See also TANH

 
%   Copyright 2019 The MathWorks, Inc.

