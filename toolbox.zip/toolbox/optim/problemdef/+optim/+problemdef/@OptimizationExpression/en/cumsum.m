%CUMSUM Cumulative sum of elements.
%   Y = CUMSUM(X) computes the cumulative sum along the first non-singleton
%   dimension of X. Y is the same size as X.
% 
%   Y = CUMSUM(X,DIM) cumulates along the dimension specified by DIM.
% 
%   Y = CUMSUM(___,DIRECTION) cumulates in the direction specified by
%   DIRECTION using any of the above syntaxes:
%     'forward' - (default) uses the forward direction, from beginning to end.
%     'reverse' -           uses the reverse direction, from end to beginning.
%   
%   Note that the NANFLAG option is not supported when X is an
%   OptimizationExpression or OptimizationVariable.
%
%   See also CUMSUM

 
%   Copyright 2019 The MathWorks, Inc.

