% TAN    Tangent of argument in radians.
%    TAN(X) is the tangent of the elements of X.
% 
%    See also TAN

 
%   Copyright 2019 The MathWorks, Inc.

