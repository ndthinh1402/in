% ATAN   Inverse tangent, result in radians.
%    ATAN(X) is the arctangent of the elements of X.
% 
%    See also ATAN

 
%   Copyright 2019 The MathWorks, Inc.

