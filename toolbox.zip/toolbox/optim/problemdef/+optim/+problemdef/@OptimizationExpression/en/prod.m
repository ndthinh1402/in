%PROD Product of elements.
%   P = PROD(X) is the product of the elements of the vector X. If X is a
%   matrix, P is a row vector with the product over each column. For 
%   N-D arrays, PROD(X) operates on the first non-singleton dimension.
%
%   PROD(X,'all') computes the product of all elements of X.   
%
%   PROD(X,DIM) operates along the dimension DIM.
%
%   PROD(X,VECDIM) operates on the dimensions specified in the vector 
%   VECDIM. For example, PROD(X,[1 2]) operates on the elements contained
%   in the first and second dimensions of X.
%
%   Note that the TYPE and NANFLAG options are not supported when X is an
%   OptimizationExpression or OptimizationVariable.
% 
%   See also PROD, SUM, CUMPROD, DIFF.

 
%   Copyright 2019 The MathWorks, Inc.

