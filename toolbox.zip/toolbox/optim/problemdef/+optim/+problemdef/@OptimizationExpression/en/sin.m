% SIN    Sine of argument in radians.
%    SIN(X) is the sine of the elements of X.
% 
%    See also SIN

 
%   Copyright 2019 The MathWorks, Inc.

