%LOG   Logarithm.
%   LOG(X) is the logarithm of the elements of X.
%
%   See also LOG.

 
%   Copyright 2019 The MathWorks, Inc.

