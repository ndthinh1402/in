%PROB2STRUCT Convert an OptimizationProblem to solver form.
%
% PROBLEMSTRUCT = PROB2STRUCT(PROB) converts the OptimizationProblem input
% PROB and returns a structure that contains the solver name, solver
% options and problem description in a form the solver can use.
%
% PROBLEMSTRUCT = PROB2STRUCT(PROB, X0) additionally specifies an initial
% point. X0 is a structure with fieldnames that match the 'Name' property
% of the OptimizationVariables in the problem.
%
% PROBLEMSTRUCT = PROB2STRUCT(___, NAME, VALUE) specifies additional
% options for PROB2STRUCT using one or more name-value pair arguments:
%
% 'Options'                - Options for the solver
% 'ObjectiveFunctionName'  - Name of the generated objective function.
%                            Used in problemStruct.objective.
% 'ConstraintFunctionName' - Name of the generated constraint function.
%                            Used in problemStruct.nonlcon.
% 'FileLocation'           - Location for exported objective, constraint and
%                            other required subfunctions.

 
%   Copyright 2017-2019 The MathWorks, Inc.

