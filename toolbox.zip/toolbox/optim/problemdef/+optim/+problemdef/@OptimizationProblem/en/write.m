%WRITE Write a problem to file
%
%   WRITE(PROB) writes a mathematical form of the problem to a text
%   file. The filename is the workspace name of the problem, PROB, appended
%   with '.txt'. If writeproblem cannot construct the file name from the
%   input problem, it writes to the file 'WriteProblemOutput.txt'.
%   writeproblem overwrites any existing file.
%
%   WRITE(PROB, FILENAME) writes a mathematical form of the
%   problem in the specified file. 
%
%   See also OPTIM.INTERNAL.PROBLEMDEF.OPTIMIZATIONPROBLEM/SHOW, 
%            OPTIMPROBLEM, EQNPROBLEM

 
%   Copyright 2019 The MathWorks, Inc.

