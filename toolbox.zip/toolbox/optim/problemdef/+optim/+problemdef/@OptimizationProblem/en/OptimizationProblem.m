classdef OptimizationProblem< optim.internal.problemdef.ProblemImpl
%OPTIMIZATIONPROBLEM Optimization problem specification
%
%   OptimizationProblem contains OptimizationExpressions and
%   OptimizationConstraints that constitute an optimization problem.
%
%   Use the OPTIMPROBLEM function to initialize an OptimizationProblem.
%
%   Construct an OptimizationProblem with a custom description, for example
%
%   problem = optimproblem('Description','My Example Problem');
%
%   See also OPTIMPROBLEM

     
    %   Copyright 2016-2019 The MathWorks, Inc.

    methods
    end
    properties
        Constraints;

        Objective;

        ObjectiveSense;

    end
end
