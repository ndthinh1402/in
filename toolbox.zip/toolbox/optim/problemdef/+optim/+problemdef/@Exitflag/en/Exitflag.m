classdef Exitflag< double & matlab.mixin.CustomDisplay
%EXITFLAG Exit flag for optimization or equation problem
%
%   Exitflag is an enumeration type that identifies the reason the solver
%   terminated.
%
%   See also OPTIMPROBLEM, EQNPROBLEM

     
%   Copyright 2017-2019 The MathWorks, Inc.

    methods
    end
end
