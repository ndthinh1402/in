classdef OptimizationConstraint< matlab.mixin.CustomDisplay
%OPTIMIZATIONCONSTRAINT Constraints for optimization and equation problems
%
%   OptimizationConstraint contains one or more constraints expressions in
%   terms of OptimizationVariables.
%
%   Construct a constraint by constraining expressions, for example
%
%   x = optimvar('x');
%   y = optimvar('y');
%   c = 2*x + 3*y <= 5
%
%   % Create 4 equalities 
%   Z = optimvar('Z',4,3);
%   constrsum = sum(Z,2) == 1;
%
%   Use the OPTIMCONSTR function to create an uninitialized array of
%   OptimizationConstraints.
%
%   See also OPTIMCONSTR

 
%   Copyright 2017-2019 The MathWorks, Inc.

    methods
    end
    properties
        % Note: We don't perform size checks on any of the private
        % properties as this would incur unnecessary overhead. Type checks
        % seem to have negligible overhead, so seems like best practice to
        % add them here.
        Expr1;

        Expr2;

        IndexNames;

        % Internal storage for IndexNames
        IndexNamesStore;

        Size;

        Variables;

    end
end
