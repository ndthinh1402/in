%NUMEL   Number of elements in an OptimizationConstraint array.
%
%   See also NUMEL.

 
%   Copyright 2017 The MathWorks, Inc.

