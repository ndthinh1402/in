%LENGTH Length of OptimizationConstraint.
%
%   See also LENGTH.

 
%   Copyright 2017 The MathWorks, Inc.

