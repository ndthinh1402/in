%VERTCAT Vertical concatenation of OptimizationConstraints.
%
%   See also VERTCAT.

 
%   Copyright 2017 The MathWorks, Inc. 

