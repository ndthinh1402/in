% ' Transpose.
%
%   CON' transposes the OptimizationConstraint, CON.

  
%   Copyright 2017 The MathWorks, Inc.

