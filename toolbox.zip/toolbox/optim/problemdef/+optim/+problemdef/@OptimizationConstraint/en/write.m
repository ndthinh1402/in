%WRITE Write an OptimizationConstraint to a text file
%
%   WRITE(CON) writes a simplified mathematical form of the
%   OptimizationConstraint into a text file. The file name is the workspace
%   name of the OptimizationConstraint CON, appended with '.txt'. If
%   writeconstr cannot construct the file name from the input constraint,
%   it writes to the file 'WriteConstrOutput.txt'. writeconstr overwrites
%   any existing file.
%
%   WRITE(CON, FILENAME) writes a simplified mathematical form of the
%   OptimizationConstraint in the specified file.
%
%   See also OPTIM.PROBLEMDEF.OPTIMIZATIONCONSTRAINT/SHOW, OPTIMCONSTR

 
%   Copyright 2019 The MathWorks, Inc.

