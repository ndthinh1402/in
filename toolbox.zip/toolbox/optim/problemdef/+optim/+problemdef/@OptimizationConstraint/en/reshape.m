%RESHAPE Reshape OptimizationConstraint array
%
%   See also RESHAPE

 
% Copyright 2017 The MathWorks, Inc.

