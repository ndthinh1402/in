%SHOW Display an OptimizationConstraint
%
%   SHOW(CON) displays the mathematical form of the OptimizationConstraint
%   in the command window. Each constraint is expanded and simplified.
%
%   See also OPTIM.PROBLEMDEF.OPTIMIZATIONCONSTRAINT/WRITE, OPTIMCONSTR

 
%   Copyright 2019 The MathWorks, Inc.

