%HORZCAT Horizontal concatenation of OptimizationConstraints.
%
%   See also HORZCAT

 
%   Copyright 2017 The MathWorks, Inc. 

