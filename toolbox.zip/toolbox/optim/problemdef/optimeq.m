function eqs = optimeq(varargin)
%OPTIMEQ Create an optimization equality array
%
%   EQS = OPTIMEQ(N) creates an N-by-1 vector of optimization
%   equalities.
%
%   EQS = OPTIMEQ(N1,N2,...) or OPTIMEQ([N1 N2 ...]) creates an
%   N1-by-N2-by-... array of uninitialized optimization equalities.
%
%   EQS = OPTIMEQ(CSTR) creates an array of uninitialized
%   optimization equalities from the cell array of character vectors or
%   string vector CSTR. EQS is 1-by-N if CSTR is 1-by-N, otherwise
%   EQS is N-by-1, where N is the number of elements of CSTR. EQS can
%   be indexed by the character vectors or strings in CSTR.
%
%   EQS = OPTIMEQ(CSTR1,CSTR2,...) or OPTIMEQ({CSTR1,
%   CSTR2,...}) creates an NCSTR1-by-NCSTR2-by-... array of uninitialized 
%   optimization equalities. CSTRi is either a cell array of character
%   vectors or a string vector. NCSTRi is the number of character vectors
%   or strings in each input, CSTRi. EQS can be indexed in the i-th
%   dimension by the character vectors or strings in CSTRi.
%   
%   EQS = OPTIMEQ(CSTR1,N2,...) or OPTIMEQ({CSTR1, N2,...})
%   creates an NCSTR1-by-N2-by-... array of uninitialized optimization
%   equalities defined by a combination of numeric values and character
%   arrays or stings. CSTRi is either a cell array of character vectors or
%   a string vector. Ni is a double indicating the size of the equalities
%   in the i-th dimension.
%
%   Examples:
%   % Create a 4-by-1 equality array
%   eq1 = optimeq(4)
%
%   % Create a 3-by-2 equality array
%   eq2 = optimeq(3, 2)
% 
%   % Create a 1-by-3 equality array where the columns can be 
%   % indexed by character vectors
%   eq3 = optimeq({'bos', 'jfk', 'lax'})
% 
%   % Create a 2-by-3 equality array with character vector indexing
%   % in each direction
%   eq4 = optimeq({'corn', 'wheat'}, {'bos', 'jfk', 'lax'})
%
%   % Create a 2-by-4-by-3 array with character vector indexing in the
%   % dimensions 1 and 3
%   eq5 = optimeq({'corn', 'wheat'}, 4, {'bos', 'jfk', 'lax'})

%   See also OPTIMVAR, OPTIMINEQ, OPTIMCONSTR

%   Copyright 2019 The MathWorks, Inc.

% Parse inputs
[outNames, outSize, NVpair] = optim.internal.problemdef.formatDimensionInput(varargin);

% There are no valid name value pairs for optimeq. If anyone tries to
% use one, we need to throw a helpful error message.
if ~isempty(NVpair)
    error(message('optim_problemdef:validateIndexNames:InvalidDimensionInput'));
end

% floor size values to zero
outSize(outSize < 0) = 0;

% Forward to equality constructor
eqs = optim.problemdef.OptimizationEquality(outSize, outNames);
