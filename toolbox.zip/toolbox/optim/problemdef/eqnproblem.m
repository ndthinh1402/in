function prob = eqnproblem(varargin)
%EQNPROBLEM Create an equation solving problem. 
%
%   PROB = EQNPROBLEM creates an equation solving problem with default
%   properties.
%
%   PROB = EQNPROBLEM(NAME, VALUE, ...) creates an equation solving problem 
%   with specified values of optional parameters:
%
%     'Equations'        An OptimizationEquality array or a struct with 
%                        OptimizationEquality arrays as fields
%     'Description'      Problem description: character array or string.
%   
%   The following simple example illustrates how an equation solving
%   problem is created and solved
%
%   % Create an equation solving problem
%   prob = eqnproblem('Description', 'Simple Example');
%  
%   % Create a 2-by-1 optimization variable
%   x = optimvar('x', 2, 1);
%
%   % Define the equations
%   prob.Equations.MyEquations = [2*x(1) - x(2) == 1 - x(1) + 0.5*x(1)^2;
%                                 -x(1) + 2*x(2) == 1 - x(2) + 0.5*x(2)^2];
%
%   % Make an initial guess
%   initialPoint.x = ones(2,1);
%
%   % Solve the problem
%   sol = solve(prob,initialPoint);
%
%   See also OPTIMVAR, OPTIMEQ

%   Copyright 2019 The MathWorks, Inc.

% Forward to problem constructor 
prob = optim.problemdef.EquationProblem();

for i = 1:2:length(varargin)
    % Let MATLAB handle whether the property exists, and let the set
    % methods handle the type validity checking
    if isStringScalar(varargin{i})
        varargin{i} = char(varargin{i});
    elseif ~ischar(varargin{i})
        error('optim_problemdef:EquationProblem:PropNameNotChar', ...
            getString(message('optim_problemdef:ProblemImpl:PropNameNotChar')));
    end
        
    prob.(varargin{i}) = varargin{i+1};
end
