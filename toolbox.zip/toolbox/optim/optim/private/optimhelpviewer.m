function optimhelpviewer()
% OPTIMHELPVIEWER is a helper file for Optimtool. 

%   Copyright 2006-2019 The MathWorks, Inc. 

try
    helpview('optim', 'optimtool');
catch
    msg = getString(message('optim:optimtool:UnableToOpenHelp'));
    errordlg(msg);
end
