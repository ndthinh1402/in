function [exitflag,msg] = formatFsolveMessage(resnorm,sqrtTolFunValue,exitflag, ...
                                            msgData,algorithmflag,makeExitMsg, solverName)
%FORMATFSOLVEMESSAGE Change lsq messages to equation solving messages
%
%   [EXITFLAG,MSG] = FORMATFSOLVEMESSAGE(RESNORM,SQRTTOLFUNVALUE,EXITFLAG,...
%   MSGDATA,ALGORITHMFLAG,MAKEEXITMSG, SOLVERNAME) takes the EXITFLAG and
%   MSGDATA plus other inputs and maps the exit status/message for equation
%   solving.

%   Copyright 2019 The MathWorks, Inc.

if nargin < 7
    solverName = 'fsolve';
end

msg = '';

if makeExitMsg
    
    if exitflag > 0 % if we think we converged:
        % Call createExitMsg with appended additional information on the
        % closeness to a root.
        
        basicID = msgData{1}{1};
        detailedID = '';
        if ~isempty(msgData{2})
            detailedID = msgData{2}{1};
        end
        
        % The solver name is required for the "Equation Solved" messages.
        if any(contains(basicID, {'Exit1basic', 'Exit100basic'}))
            msgData{1}{2} = solverName;
        end
        
        idPieces = split(basicID,':');
        % Default to using dogleg message
        basicID = char("optim:fsolve:" + idPieces(3));
        if ~isempty(detailedID)
            idPieces = split(detailedID,':');
            % Default to using dogleg message
            detailedID = char("optim:fsolve:" + idPieces(3));
        end
        if algorithmflag == 1  % trust-region
            % Shares msgs with dogleg for exitflags: 100, 1, -21
            % Shares msgs with L-M for exitflags: 3, -23
            % Has its own msg: 2, -22
            if exitflag == 3 % Use LM messages
                basicID = basicID + "LM";
                if ~isempty(detailedID)
                    detailedID = detailedID + "LM";
                    % The exitflag = 3,4 messages for LM require the solver name.
                    msgData{2} = [msgData{2}(1), {solverName}, msgData{2}(2:end)];
                end
            elseif exitflag == 2
                basicID = basicID + "SNLS";
                if ~isempty(detailedID)
                    detailedID = detailedID + "SNLS";
                    % The exitflag = 2 messages for SNLS require the solver name.
                    msgData{2} = [msgData{2}(1), {solverName}, msgData{2}(2:end)];
                end
            end
        elseif algorithmflag == 3 % L-M
            % Shares msgs with dogleg for exitflags: 26, -27
            % Shares msgs with trust-region for exitflags: 3, -23
            % Has its own msg: 100, 1, 2, 4, -21, -24
            basicID = basicID + "LM";
            if ~isempty(detailedID)
                detailedID = detailedID + "LM";
                if exitflag >= 2 && exitflag <= 4
                    % The exitflag = 2,3,4 messages for LM require the solver name.
                    msgData{2} = [msgData{2}(1), {solverName}, msgData{2}(2:end)];
                end
            end
        end
        
        if resnorm > sqrtTolFunValue
            % All algorithms -
            % Result is not a root: change internal exitflag to negative
            flag = -20 - exitflag;
            % Flip to negative
            basicID = regexprep(basicID,'\d+',"Neg" + abs(flag));
            if ~isempty(detailedID)
                detailedID = regexprep(detailedID,'\d+',"Neg" + abs(flag));
                if contains(detailedID, 'optim:fsolve:ExitNeg21detailed')
                    msgData{2} = [msgData{2}(1), {solverName}, msgData{2}(2:end)];
                end
            end
            exitflag = -2;
        end
        
        if contains(idPieces(3),'26')
            % Algorithm trust-region-dogleg or L-M, stopped because of undefined
            % Jacobian and not near a root
            basicID = 'optim:fsolve:ExitNeg27basic';
        elseif ~isempty(detailedID)
            % Append residual and sqrt(TolFunValue) for fsolve-specific message
            % Add the residual norm and tolerance to the inputs for
            % creating the detailed message in the "<stopping criteria
            % details>" link.
            msgData{2} = [msgData{2} {resnorm,sqrtTolFunValue}];
        end
        % Re-assign msg IDs
        msgData{1}{1} = basicID;
        if ~isempty(detailedID)
            msgData{2}{1} = detailedID;
        end
    end
    msg = createExitMsg(msgData{:});
else % ~makeExitMsg
    % If we are not going to fetch an exit message, then we can skip all of
    % the ID scraping and various formatting code.
    % Instead, just check the original flag and adjust if the residual is
    % too large.
    % NOTE: this is duplicate logic to what is mixed in the code above.
    % However, it's simple and it will cut down time.
    
    if exitflag > 0 && resnorm > sqrtTolFunValue
        % Result is not a root: change internal exitflag to negative
        exitflag = -2;
    end
    
end
