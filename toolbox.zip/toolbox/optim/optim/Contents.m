% Optimization Toolbox
% Version 8.5 (R2020a) 18-Nov-2019 
%
% Nonlinear minimization of functions.
%   fminbnd      - Scalar bounded nonlinear function minimization.
%   fmincon      - Multidimensional constrained nonlinear minimization.
%   fminsearch   - Multidimensional unconstrained nonlinear minimization, 
%                  by Nelder-Mead direct search method.
%   fminunc      - Multidimensional unconstrained nonlinear minimization.
%   fseminf      - Multidimensional constrained minimization, semi-infinite 
%                  constraints.
%
% Nonlinear minimization of multi-objective functions.
%   fgoalattain  - Multidimensional goal attainment optimization 
%   fminimax     - Multidimensional minimax optimization.
%        
% Linear least squares (of matrix problems).
%   lsqlin       - Linear least squares with linear constraints.
%   lsqnonneg    - Linear least squares with nonnegativity constraints.
%
% Nonlinear least squares (of functions).
%   lsqcurvefit  - Nonlinear curvefitting via least squares (with bounds).
%   lsqnonlin    - Nonlinear least squares with upper and lower bounds.
%
% Nonlinear zero finding (equation solving).
%   fzero        - Scalar nonlinear zero finding.
%   fsolve       - Nonlinear system of equations solve (function solve).
%
% Minimization of matrix problems.
%   intlinprog   - Mixed integer linear programming.
%   linprog      - Linear programming.
%   quadprog     - Quadratic programming.
%
% Controlling defaults and options.
%   optimoptions - Create or alter optimization OPTIONS
%
% Graphical user interface and plot routines
%   optimtool                   - Optimization Toolbox Graphical User 
%                                 Interface
%   optimplotconstrviolation    - Plot max. constraint violation at each 
%                                 iteration
%   optimplotfirstorderopt      - Plot first-order optimality at each 
%                                 iteration
%   optimplotresnorm            - Plot value of the norm of residuals at
%                                 each iteration
%   optimplotstepsize           - Plot step size at each iteration

%   Copyright 1990-2019 The MathWorks, Inc.
